
import { ShopConfig, Category, Product } from './types';

export const INITIAL_CONFIG: ShopConfig = {
  name: 'Saúde Suplementa',
  logo: 'https://images.unsplash.com/photo-1579722820308-d74e5719d23e?q=80&w=200&h=200&auto=format&fit=crop',
  banner: 'https://images.unsplash.com/photo-1540206276207-3af25c08abb4?q=80&w=1080&h=400&auto=format&fit=crop',
  whatsapp: '5511977693913',
  address: 'Atendimento Online - Envio para todo Brasil',
  theme: 'tech',
  isOpen: true,
  enableDeliveryFee: true,
  deliveryFee: 15,
  minOrder: 0,
  deliveryType: 'fixed',
  neighborhoodFees: {},
  pixKey: '11977693913',
  pixName: 'Saúde Suplementa',
  popupEnabled: true,
  popupTitle: '⚡ OFERTA DE PERFORMANCE',
  popupDescription: 'Combo Whey Isolado + Creatina com frete grátis apenas hoje.',
  popupImage: 'https://images.unsplash.com/photo-1593095948071-474c5cc2989d?q=80&w=800&auto=format&fit=crop',
  popupButtonText: 'GARANTIR AGORA',
  enableCheckoutUrl: false,
  checkoutUrl: '',
  enableWhatsAppCheckout: true,
  whatsappMessageTemplate: `Olá! Quero finalizar meu pedido na Saúde Suplementa.

🛒 Itens:
{{ITENS}}

💰 Total: R$ {{TOTAL}}

Prefiro pagar via Pix ou Cartão.`,
  whatsappHelpMessage: 'Olá! Tenho uma dúvida sobre um suplemento.',
  whatsappPostOrderMessage: 'Recebemos seu pedido! Um consultor entrará em contato em instantes.',
  enableAutoMessages: true
};

export const INITIAL_CATEGORIES: Category[] = [
  { id: 'cat1', name: 'Proteínas', order: 0, active: true, icon: '💪' },
  { id: 'cat2', name: 'Creatinas', order: 1, active: true, icon: '⚡' },
  { id: 'cat3', name: 'Pré-Treinos', order: 2, active: true, icon: '🔥' },
];

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: 'p1',
    categoryId: 'cat1',
    name: 'Whey Protein Isolado 900g',
    description: '25g de proteína pura por dose. Zero carbo, absorção imediata para recuperação muscular.',
    price: 189.90,
    oldPrice: 249.00,
    images: ['https://images.unsplash.com/photo-1593095948071-474c5cc2989d?q=80&w=600&h=600&auto=format&fit=crop'],
    tags: ['bestseller', 'promo'],
    inStock: true,
    extrasEnabled: true,
    checkoutEnabled: true,
    checkoutLink: 'https://pay.hotmart.com/example-whey',
    variations: [
      { id: 'v1', name: 'Sabor', required: true, options: ['Chocolate Belga', 'Baunilha Cream', 'Morango Silvestre'] }
    ],
    extras: [{ id: 'e1', name: 'Coqueteleira PRO', price: 29.90 }]
  },
  {
    id: 'p2',
    categoryId: 'cat2',
    name: 'Creatina Monohidratada 300g',
    description: 'Aumento real de força e volume muscular. 100% pura, aprovada em laudos.',
    price: 97.00,
    oldPrice: 130.00,
    images: ['https://images.unsplash.com/photo-1517836357463-d25dfeac3438?q=80&w=600&h=600&auto=format&fit=crop'],
    tags: ['highlight'],
    inStock: true,
    extrasEnabled: false,
    checkoutEnabled: true,
    checkoutLink: 'https://pay.hotmart.com/example-creatina',
    variations: [],
    extras: []
  }
];
