
export type Theme = 'light' | 'dark' | 'food' | 'tech';

export interface ShopConfig {
  name: string;
  logo: string;
  banner: string;
  whatsapp: string;
  address: string;
  theme: Theme;
  isOpen: boolean;
  paymentLink?: string;
  pixKey?: string;
  pixName?: string;
  pixQrCode?: string;
  enableDeliveryFee: boolean;
  deliveryFee: number;
  minOrder: number;
  deliveryType: 'fixed' | 'neighborhood';
  neighborhoodFees: Record<string, number>;
  popupEnabled: boolean;
  popupTitle: string;
  popupDescription: string;
  popupImage?: string;
  popupButtonText: string;
  enableCheckoutUrl: boolean;
  checkoutUrl: string;
  enableWhatsAppCheckout: boolean;
  whatsappMessageTemplate: string;
  whatsappHelpMessage: string;
  whatsappPostOrderMessage: string;
  enableAutoMessages: boolean;
}

export interface Category {
  id: string;
  name: string;
  order: number;
  active: boolean;
  icon?: string;
}

export interface VariationGroup {
  id: string;
  name: string;
  required: boolean;
  options: string[];
}

export interface Extra {
  id: string;
  name: string;
  price: number;
}

export interface Product {
  id: string;
  categoryId: string;
  name: string;
  description: string;
  price: number;
  oldPrice?: number | null;
  images: string[];
  tags: ('promo' | 'highlight' | 'bestseller' | 'new')[];
  inStock: boolean;
  variations: VariationGroup[];
  extras: Extra[];
  extrasEnabled: boolean; // Flag para Upsell on/off
  checkoutLink?: string;
  checkoutEnabled: boolean; // Flag para Checkout on/off
  updatedAt?: number;
}

export interface CartItem {
  cartId: string;
  productId: string;
  quantity: number;
  selectedVariations: Record<string, string>;
  selectedExtras: string[];
  observation: string;
}

export type OrderStatus = 'new' | 'confirmed' | 'preparing' | 'shipped' | 'delivered' | 'cancelled';

export interface Order {
  id: string;
  customerName: string;
  customerPhone: string;
  items: CartItem[];
  total: number;
  deliveryType: 'delivery' | 'pickup';
  address?: string;
  neighborhood?: string;
  paymentMethod: 'whatsapp' | 'pix' | 'link';
  status: OrderStatus;
  createdAt: number;
}
