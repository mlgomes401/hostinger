
import React, { useState, useMemo } from 'react';
import { useApp } from '../App';
import { useNavigate, useLocation } from 'react-router-dom';
import { IconWhatsApp, IconPix } from './Icons';
import { storage } from '../services/storage';

export const GlobalCheckoutBar: React.FC = () => {
  const { cart, products, config, clearCart } = useApp();
  const navigate = useNavigate();
  const location = useLocation();
  const [showDrawer, setShowDrawer] = useState(false);
  const [method, setMethod] = useState<'whatsapp' | 'link' | null>(null);

  const customerData = storage.getCustomerInfo();
  const [name, setName] = useState(customerData.name);
  const [phone, setPhone] = useState(customerData.phone);
  const [address, setAddress] = useState(customerData.address);

  const isCheckoutEnabled = useMemo(() => {
    return config.enableCheckoutUrl && config.checkoutUrl && config.checkoutUrl.trim().length > 0;
  }, [config.enableCheckoutUrl, config.checkoutUrl]);

  const isExcludedPage = useMemo(() => {
    return location.pathname.startsWith('/admin') || 
           location.pathname === '/sucesso' || 
           location.pathname === '/carrinho';
  }, [location.pathname]);

  const financialSummary = useMemo(() => {
    const total = cart.reduce((acc, item) => {
      const p = products.find(prod => prod.id === item.productId);
      if (!p) return acc;
      const extrasPrice = p.extras
        .filter(e => item.selectedExtras.includes(e.id))
        .reduce((a, c) => a + Number(c.price), 0);
      return acc + (Number(p.price) + extrasPrice) * item.quantity;
    }, 0);
    const delivery = config.enableDeliveryFee ? config.deliveryFee : 0;
    return { total, finalTotal: total + delivery };
  }, [cart, products, config]);

  if (cart.length === 0 || isExcludedPage) return null;

  const handleCheckoutClick = (m: 'whatsapp' | 'link') => {
    setMethod(m);
    if (name.trim() && phone.trim()) {
      processFinalCheckout(m);
    } else {
      setShowDrawer(true);
    }
  };

  const processFinalCheckout = (m: 'whatsapp' | 'link') => {
    // 1. Salva dados do cliente
    storage.setCustomerInfo({ name, phone, address });

    // 2. Registra o pedido no Banco de Dados (localStorage)
    const newOrder = {
      id: Math.random().toString(36).substr(2, 5).toUpperCase(),
      customerName: name,
      customerPhone: phone,
      items: [...cart],
      total: financialSummary.finalTotal,
      deliveryType: 'delivery',
      paymentMethod: m,
      status: 'new',
      createdAt: Date.now()
    };
    storage.addOrder(newOrder as any);

    // 3. Prepara mensagem do WhatsApp
    const orderLines = cart.map(item => {
      const p = products.find(prod => prod.id === item.productId);
      const variations = Object.values(item.selectedVariations).join(', ');
      return `${item.quantity}x ${p?.name}${variations ? ` (${variations})` : ''}`;
    }).join('\n');

    if (m === 'whatsapp') {
      let message = config.whatsappMessageTemplate || `Olá! 👋 Meu nome é *{{NOME}}*.\n\nQuero finalizar meu pedido:\n\n🛒 Pedido:\n{{ITENS}}\n\n💳 Total: R$ {{TOTAL}}\n\n📍 Endereço:\n{{ENDERECO}}`;
      message = message
        .replace(/{{NOME}}/g, name)
        .replace(/{{ITENS}}/g, orderLines)
        .replace(/{{TOTAL}}/g, financialSummary.finalTotal.toFixed(2))
        .replace(/{{ENDERECO}}/g, address || 'Retirada no local');

      window.open(`https://wa.me/${config.whatsapp}?text=${encodeURIComponent(message)}`, '_blank');
    } else {
      const url = config.checkoutUrl.startsWith('http') ? config.checkoutUrl : `https://${config.checkoutUrl}`;
      window.open(url, '_blank');
    }

    // 4. Finaliza
    clearCart();
    navigate('/sucesso');
    setShowDrawer(false);
  };

  return (
    <>
      <div className="fixed bottom-24 left-4 right-4 z-[90] animate-in slide-in-from-bottom-10 duration-500">
        <div className="bg-white/95 backdrop-blur-xl border border-white shadow-[0_20px_50px_rgba(0,0,0,0.15)] rounded-[32px] p-3 flex items-center justify-between gap-3">
          <div className="flex flex-col pl-4 flex-grow cursor-pointer" onClick={() => navigate('/carrinho')}>
            <span className="text-[9px] font-black text-blue-600 uppercase tracking-widest">Sua Sacola</span>
            <span className="text-lg font-black text-gray-900 tracking-tighter">R$ {financialSummary.total.toFixed(2)}</span>
          </div>
          
          <div className="flex gap-2">
            <button 
              onClick={() => handleCheckoutClick('whatsapp')}
              className={`${isCheckoutEnabled ? 'bg-green-500' : 'bg-green-600 w-full px-8'} text-white p-4 rounded-2xl shadow-lg active:scale-95 transition-all flex items-center justify-center gap-2`}
            >
              <IconWhatsApp size={20} />
              {!isCheckoutEnabled && <span className="text-[10px] font-black uppercase tracking-widest">Finalizar</span>}
            </button>
            
            {isCheckoutEnabled && (
              <button 
                onClick={() => handleCheckoutClick('link')}
                className="bg-gray-900 text-white px-6 py-4 rounded-2xl flex items-center gap-2 shadow-lg active:scale-95 transition-all"
              >
                <IconPix size={18} />
                <span className="text-[10px] font-black uppercase tracking-widest">Pagar</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {showDrawer && (
        <div className="fixed inset-0 z-[150] flex items-end justify-center">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setShowDrawer(false)} />
          <div className="relative bg-white w-full max-w-xl rounded-t-[44px] p-8 space-y-6 animate-in slide-in-from-bottom duration-300 shadow-2xl">
            <div className="w-12 h-1.5 bg-gray-100 rounded-full mx-auto mb-4" />
            <h3 className="text-xl font-black text-gray-900 uppercase tracking-tighter text-center">Identificação</h3>
            
            <div className="space-y-4">
              <input value={name} onChange={e => setName(e.target.value)} className="w-full bg-gray-50 border-none rounded-2xl p-5 text-sm font-bold shadow-inner" placeholder="Seu Nome Completo" />
              <input value={phone} onChange={e => setPhone(e.target.value)} className="w-full bg-gray-50 border-none rounded-2xl p-5 text-sm font-bold shadow-inner" placeholder="Seu WhatsApp" />
              <textarea value={address} onChange={e => setAddress(e.target.value)} className="w-full bg-gray-50 border-none rounded-2xl p-5 text-sm font-bold h-24 resize-none shadow-inner" placeholder="Endereço de entrega (opcional)" />
            </div>

            <button 
              onClick={() => method && processFinalCheckout(method)}
              className={`w-full ${method === 'whatsapp' ? 'bg-green-600' : 'bg-blue-600'} text-white font-black py-6 rounded-[28px] shadow-2xl uppercase text-[11px] tracking-[0.2em]`}
            >
              Confirmar e Enviar Pedido
            </button>
          </div>
        </div>
      )}
    </>
  );
};
