
import React from 'react';

interface ToastProps {
  message: string;
  type: 'success' | 'error' | 'info';
  onClose: () => void;
}

export const Toast: React.FC<ToastProps> = ({ message, type, onClose }) => {
  const bgColors = {
    success: 'bg-green-600',
    error: 'bg-red-600',
    info: 'bg-gray-800'
  };

  return (
    <div className="fixed bottom-24 left-1/2 -translate-x-1/2 lg:bottom-10 lg:left-auto lg:right-10 lg:translate-x-0 z-[200] animate-in slide-in-from-bottom-5 fade-in duration-300 pointer-events-none">
      <div className={`${bgColors[type]} text-white px-6 py-3.5 rounded-2xl shadow-2xl flex items-center gap-3 pointer-events-auto`}>
        <span className="text-sm font-black tracking-tight">{message}</span>
      </div>
    </div>
  );
};

interface ConfirmModalProps {
  title: string;
  message: string;
  onConfirm: () => void;
  onCancel: () => void;
}

export const ConfirmModal: React.FC<ConfirmModalProps> = ({ title, message, onConfirm, onCancel }) => {
  return (
    <div className="fixed inset-0 z-[300] bg-black/60 backdrop-blur-sm flex items-center justify-center p-6 animate-in fade-in duration-300">
      <div className="bg-white w-full max-w-sm rounded-[40px] p-8 shadow-2xl text-center animate-in zoom-in-95 duration-300">
        <h2 className="text-2xl font-black mb-2 uppercase tracking-tighter text-gray-900">{title}</h2>
        <p className="text-gray-500 text-sm mb-8 leading-relaxed font-medium">{message}</p>
        
        <div className="grid grid-cols-2 gap-3">
          <button 
            onClick={onCancel}
            className="py-4 bg-gray-100 text-gray-500 rounded-2xl font-black text-xs uppercase active:scale-95 transition-all"
          >
            Cancelar
          </button>
          <button 
            onClick={onConfirm}
            className="py-4 bg-red-600 text-white rounded-2xl font-black text-xs uppercase shadow-lg shadow-red-100 active:scale-95 transition-all"
          >
            Confirmar
          </button>
        </div>
      </div>
    </div>
  );
};
