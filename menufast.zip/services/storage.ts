
import { ShopConfig, Category, Product, Order } from '../types';
import { INITIAL_CONFIG, INITIAL_CATEGORIES, INITIAL_PRODUCTS } from '../constants';

const KEYS = {
  CONFIG: 'mf_config',
  CATEGORIES: 'categories',
  PRODUCTS: 'products',
  ORDERS: 'mf_orders',
  CUSTOMER_INFO: 'mf_customer_info',
};

export interface CustomerInfo {
  name: string;
  phone: string;
  address: string;
}

export const storage = {
  getConfig: (): ShopConfig => {
    const data = localStorage.getItem(KEYS.CONFIG);
    return data ? JSON.parse(data) : INITIAL_CONFIG;
  },
  setConfig: (config: ShopConfig) => localStorage.setItem(KEYS.CONFIG, JSON.stringify(config)),

  getCategories: (): Category[] => {
    const data = localStorage.getItem(KEYS.CATEGORIES);
    return data ? JSON.parse(data) : INITIAL_CATEGORIES;
  },
  setCategories: (cats: Category[]) => localStorage.setItem(KEYS.CATEGORIES, JSON.stringify(cats)),

  getProducts: (): Product[] => {
    const data = localStorage.getItem(KEYS.PRODUCTS);
    return data ? JSON.parse(data) : INITIAL_PRODUCTS;
  },
  setProducts: (prods: Product[]) => localStorage.setItem(KEYS.PRODUCTS, JSON.stringify(prods)),

  getOrders: (): Order[] => {
    const data = localStorage.getItem(KEYS.ORDERS);
    return data ? JSON.parse(data) : [];
  },
  addOrder: (order: Order) => {
    const orders = storage.getOrders();
    storage.setOrders([order, ...orders]);
  },
  setOrders: (orders: Order[]) => localStorage.setItem(KEYS.ORDERS, JSON.stringify(orders)),

  getCustomerInfo: (): CustomerInfo => {
    const data = localStorage.getItem(KEYS.CUSTOMER_INFO);
    return data ? JSON.parse(data) : { name: '', phone: '', address: '' };
  },
  setCustomerInfo: (info: CustomerInfo) => localStorage.setItem(KEYS.CUSTOMER_INFO, JSON.stringify(info)),
};
