
import React, { useState, useEffect, createContext, useContext } from 'react';
import { HashRouter, Routes, Route, useNavigate, useLocation } from 'react-router-dom';
import { storage } from './services/storage';
import { ShopConfig, Category, Product, CartItem, Order, Theme } from './types';
import ClientHome from './views/client/ClientHome';
import ProductDetail from './views/client/ProductDetail';
import CartView from './views/client/CartView';
import SuccessView from './views/client/SuccessView';
import OrdersHistory from './views/client/OrdersHistory';
import AdminLayout from './views/admin/AdminLayout';
import AdminDashboard from './views/admin/AdminDashboard';
import AdminCatalog from './views/admin/AdminCatalog';
import AdminOrders from './views/admin/AdminOrders';
import AdminSettings from './views/admin/AdminSettings';
import AdminMarketing from './views/admin/AdminMarketing';
import AdminCategories from './views/admin/AdminCategories';
import { Toast, ConfirmModal } from './components/Feedback';
import { GlobalCheckoutBar } from './components/GlobalCheckoutBar';

interface AppContextType {
  config: ShopConfig;
  setConfig: (c: ShopConfig) => void;
  categories: Category[];
  setCategories: (cats: Category[]) => void;
  products: Product[];
  setProducts: (prods: Product[]) => void;
  cart: CartItem[];
  addToCart: (item: CartItem) => void;
  removeFromCart: (cartId: string) => void;
  updateCartQty: (cartId: string, qty: number) => void;
  clearCart: () => void;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
  confirmAction: (options: { title: string, message: string, onConfirm: () => void }) => void;
}

export const AppContext = createContext<AppContextType | null>(null);

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error("useApp must be used within AppProvider");
  return context;
};

const App: React.FC = () => {
  const [config, setConfigState] = useState<ShopConfig>(storage.getConfig());
  const [categories, setCategoriesState] = useState<Category[]>(storage.getCategories());
  const [products, setProductsState] = useState<Product[]>(storage.getProducts());
  const [cart, setCart] = useState<CartItem[]>([]);
  
  // Feedback States
  const [toast, setToast] = useState<{ message: string, type: 'success' | 'error' | 'info' } | null>(null);
  const [confirm, setConfirm] = useState<{ title: string, message: string, onConfirm: () => void } | null>(null);

  const setConfig = (c: ShopConfig) => { 
    setConfigState(c); 
    storage.setConfig(c); 
    window.dispatchEvent(new CustomEvent('data:productsUpdated'));
  };
  
  const setCategories = (cats: Category[]) => { 
    setCategoriesState(cats); 
    storage.setCategories(cats); 
    window.dispatchEvent(new CustomEvent('data:productsUpdated'));
  };
  
  const setProducts = (prods: Product[]) => { 
    setProductsState(prods); 
    storage.setProducts(prods); 
    window.dispatchEvent(new CustomEvent('data:productsUpdated'));
  };

  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  const confirmAction = (options: { title: string, message: string, onConfirm: () => void }) => {
    setConfirm(options);
  };

  useEffect(() => {
    const handleUpdate = () => {
      setProductsState(storage.getProducts());
      setCategoriesState(storage.getCategories());
      setConfigState(storage.getConfig());
    };

    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === 'products' || e.key === 'categories' || e.key === 'mf_config') {
        handleUpdate();
      }
    };

    window.addEventListener('data:productsUpdated', handleUpdate);
    window.addEventListener('storage', handleStorageChange);
    
    return () => {
      window.removeEventListener('data:productsUpdated', handleUpdate);
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);

  const addToCart = (item: CartItem) => {
    setCart(prev => [...prev, item]);
    showToast('Adicionado à sacola!', 'success');
  };

  const removeFromCart = (cartId: string) => {
    setCart(prev => prev.filter(i => i.cartId !== cartId));
    showToast('Item removido', 'info');
  };

  const updateCartQty = (cartId: string, qty: number) => {
    if (qty <= 0) return removeFromCart(cartId);
    setCart(prev => prev.map(i => i.cartId === cartId ? { ...i, quantity: qty } : i));
  };
  
  const clearCart = () => {
    setCart([]);
  };

  const themeClasses = {
    light: 'bg-white text-gray-900',
    dark: 'bg-gray-900 text-white',
    food: 'bg-orange-50 text-gray-900',
    tech: 'bg-slate-50 text-gray-900',
  };

  return (
    <AppContext.Provider value={{ 
      config, setConfig, 
      categories, setCategories, 
      products, setProducts,
      cart, addToCart, removeFromCart, updateCartQty, clearCart,
      showToast, confirmAction
    }}>
      <div className={`min-h-screen ${themeClasses[config.theme]}`}>
        <HashRouter>
          {/* Barra de Checkout Global acionada aqui */}
          <GlobalCheckoutBar />
          
          <Routes>
            <Route path="/" element={<ClientHome />} />
            <Route path="/produto/:id" element={<ProductDetail />} />
            <Route path="/carrinho" element={<CartView />} />
            <Route path="/sucesso" element={<SuccessView />} />
            <Route path="/pedidos" element={<OrdersHistory />} />
            
            <Route path="/admin" element={<AdminLayout />}>
              <Route index element={<AdminDashboard />} />
              <Route path="catalogo" element={<AdminCatalog />} />
              <Route path="categorias" element={<AdminCategories />} />
              <Route path="pedidos" element={<AdminOrders />} />
              <Route path="config" element={<AdminSettings />} />
              <Route path="marketing" element={<AdminMarketing />} />
            </Route>
          </Routes>
        </HashRouter>
        
        {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
        {confirm && (
          <ConfirmModal 
            title={confirm.title} 
            message={confirm.message} 
            onConfirm={() => { confirm.onConfirm(); setConfirm(null); }} 
            onCancel={() => setConfirm(null)} 
          />
        )}
      </div>
    </AppContext.Provider>
  );
};

export default App;
