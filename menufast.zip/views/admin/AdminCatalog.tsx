
import React, { useState, useRef, useMemo } from 'react';
import { useApp } from '../../App';
import { Category, Product, VariationGroup, Extra } from '../../types';
import { IconPlus, IconTrash, IconHome, IconArrowLeft, IconPix, IconSearch } from '../../components/Icons';
import { Link } from 'react-router-dom';

const AdminCatalog: React.FC = () => {
  const { categories, products, setProducts, showToast, confirmAction } = useApp();
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [form, setForm] = useState<Partial<Product>>({});
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      const matchesCategory = filterCategory === 'all' || p.categoryId === filterCategory;
      const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesCategory && matchesSearch;
    });
  }, [products, filterCategory, searchQuery]);

  const handleEdit = (p: Product | null) => {
    if (p) {
      setEditingProduct(p);
      setForm({ ...p });
    } else {
      const newId = 'p' + Date.now();
      setEditingProduct({ id: newId } as any);
      setForm({
        id: newId,
        name: '',
        description: '',
        price: 0,
        categoryId: categories[0]?.id || '',
        images: [],
        variations: [],
        extras: [],
        extrasEnabled: true,
        checkoutEnabled: true,
        checkoutLink: '',
        inStock: true,
        tags: []
      });
    }
  };

  const handleSave = () => {
    if (!form.name || !form.categoryId) return showToast('Preencha nome e categoria', 'error');
    if (!form.images || form.images.length === 0) return showToast('Adicione pelo menos uma imagem', 'error');
    
    const productData = {
      ...form,
      price: Number(form.price),
      oldPrice: form.oldPrice ? Number(form.oldPrice) : null,
    } as Product;

    const exists = products.find(p => p.id === productData.id);
    if (!exists) {
      setProducts([...products, productData]);
    } else {
      setProducts(products.map(p => p.id === productData.id ? productData : p));
    }
    
    setEditingProduct(null);
    showToast('Produto salvo com sucesso!');
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    Array.from(files).forEach((file: File) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        const base64 = event.target?.result as string;
        setForm(prev => ({
          ...prev,
          images: [...(prev.images || []), base64]
        }));
      };
      reader.readAsDataURL(file);
    });
    showToast('Imagens adicionadas!');
  };

  const removeImage = (index: number) => {
    setForm(prev => ({
      ...prev,
      images: prev.images?.filter((_, i) => i !== index)
    }));
  };

  const addVariation = () => {
    const newVar: VariationGroup = { 
      id: 'v' + Date.now(), 
      name: '', 
      required: true, 
      options: [] 
    };
    setForm({ ...form, variations: [...(form.variations || []), newVar] });
  };

  const updateVariation = (index: number, field: string, value: any) => {
    const updated = [...(form.variations || [])];
    updated[index] = { ...updated[index], [field]: value };
    setForm({ ...form, variations: updated });
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-500 pb-20">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-5">
        <div>
          <h1 className="text-3xl font-black uppercase tracking-tighter">Catálogo de Produtos</h1>
          <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">Gerencie seu estoque e fotos</p>
        </div>
        <div className="flex gap-3">
          <Link to="/" className="flex items-center gap-2 bg-white border border-gray-100 px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-sm hover:bg-gray-50 transition-all">
            <IconHome size={14} /> Ver Loja
          </Link>
          <button onClick={() => handleEdit(null)} className="bg-blue-600 text-white px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-blue-100 flex items-center gap-2">
            <IconPlus size={16} /> Novo Produto
          </button>
        </div>
      </div>

      {/* FILTROS E BUSCA */}
      <div className="bg-white p-6 rounded-[32px] border border-gray-100 shadow-sm flex flex-col md:flex-row gap-4">
        <div className="flex-grow relative">
          <IconSearch size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-300" />
          <input 
            type="text" 
            placeholder="Buscar por nome..." 
            className="w-full bg-gray-50 border-none rounded-2xl py-4 pl-12 pr-4 text-[11px] font-bold uppercase tracking-widest outline-none focus:ring-2 focus:ring-blue-500/10 transition-all"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div className="flex gap-2 overflow-x-auto no-scrollbar">
          <button 
            onClick={() => setFilterCategory('all')}
            className={`px-6 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${filterCategory === 'all' ? 'bg-gray-900 text-white shadow-lg' : 'bg-gray-50 text-gray-400'}`}
          >
            Todos
          </button>
          {categories.map(cat => (
            <button 
              key={cat.id}
              onClick={() => setFilterCategory(cat.id)}
              className={`px-6 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${filterCategory === cat.id ? 'bg-blue-600 text-white shadow-lg' : 'bg-gray-50 text-gray-400'}`}
            >
              {cat.icon} {cat.name}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {filteredProducts.map(p => (
          <div key={p.id} className="bg-white rounded-[44px] overflow-hidden border border-gray-100 shadow-sm flex flex-col group hover:shadow-xl transition-all duration-500">
            <div className="h-64 bg-gray-50 relative overflow-hidden flex items-center justify-center p-4">
              <img 
                src={p.images[0] || 'https://placehold.co/600x600?text=Sem+Imagem'} 
                className="w-full h-full object-contain group-hover:scale-105 transition-transform duration-700" 
                alt="" 
              />
              <div className="absolute top-6 left-6 flex flex-col gap-2">
                <div className="bg-white/90 backdrop-blur px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest text-gray-900 shadow-sm border border-white/50">
                  {categories.find(c => c.id === p.categoryId)?.name || 'Sem Categoria'}
                </div>
                {p.checkoutLink && (
                  <div className="bg-blue-600 text-white px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest shadow-sm flex items-center gap-1.5">
                    <IconPix size={10}/> Checkout Ativo
                  </div>
                )}
                {!p.inStock && (
                  <div className="bg-red-500 text-white px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest shadow-sm">
                    Esgotado
                  </div>
                )}
              </div>
            </div>
            <div className="p-8 space-y-6">
              <div>
                <h4 className="font-black text-gray-900 text-lg uppercase tracking-tight truncate">{p.name}</h4>
                <div className="flex items-center gap-3 mt-2">
                   <span className="font-black text-blue-600 text-xl tracking-tighter">R$ {p.price.toFixed(2)}</span>
                   {p.oldPrice && <span className="text-xs text-gray-300 line-through font-bold">R$ {p.oldPrice.toFixed(2)}</span>}
                </div>
              </div>
              
              <div className="flex gap-3">
                <button onClick={() => handleEdit(p)} className="flex-grow bg-gray-900 text-white py-4 rounded-[20px] text-[10px] font-black uppercase tracking-widest hover:bg-blue-600 transition-all shadow-lg active:scale-95">Editar</button>
                <button onClick={() => confirmAction({ title: 'Excluir?', message: 'Remover este produto permanentemente?', onConfirm: () => setProducts(products.filter(x => x.id !== p.id)) })} className="bg-red-50 text-red-500 px-6 rounded-[20px] hover:bg-red-500 hover:text-white transition-all active:scale-95">
                   <IconTrash size={20}/>
                </button>
              </div>
            </div>
          </div>
        ))}
        {filteredProducts.length === 0 && (
          <div className="col-span-full py-20 text-center bg-gray-50 rounded-[44px] border-2 border-dashed border-gray-200">
            <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Nenhum produto encontrado nesta categoria</p>
          </div>
        )}
      </div>

      {editingProduct && (
        <div className="fixed inset-0 z-[100] bg-black/70 backdrop-blur-xl flex items-center justify-center p-4 lg:p-10 animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-5xl rounded-[56px] h-full lg:max-h-[90vh] overflow-hidden shadow-[0_40px_100px_rgba(0,0,0,0.5)] flex flex-col">
            <header className="px-10 py-8 border-b border-gray-50 flex justify-between items-center bg-white/80 backdrop-blur sticky top-0 z-20">
              <div className="flex items-center gap-4">
                 <button onClick={() => setEditingProduct(null)} className="p-3 bg-gray-50 rounded-2xl text-gray-400 hover:text-gray-900"><IconArrowLeft size={20}/></button>
                 <div>
                    <h2 className="text-2xl font-black uppercase tracking-tighter leading-none">Configurar Produto</h2>
                    <span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1 block">Fotos e Atributos</span>
                 </div>
              </div>
              <button onClick={handleSave} className="bg-blue-600 text-white px-8 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl shadow-blue-100 active:scale-95 transition-all">Salvar Tudo</button>
            </header>
            
            <div className="flex-grow overflow-y-auto p-10 space-y-16 no-scrollbar">
              <section className="space-y-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-black text-gray-900 uppercase tracking-widest">Galeria de Imagens</h3>
                  <button onClick={() => fileInputRef.current?.click()} className="bg-gray-900 text-white px-6 py-3 rounded-xl text-[9px] font-black uppercase tracking-widest">+ Carregar Fotos</button>
                  <input ref={fileInputRef} type="file" multiple accept="image/*" onChange={handleImageUpload} className="hidden" />
                </div>
                
                <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-6 gap-6">
                  {form.images?.map((img, idx) => (
                    <div key={idx} className="relative aspect-square rounded-[28px] overflow-hidden border-4 border-gray-50 group shadow-sm bg-white flex items-center justify-center p-2">
                      <img src={img} className="w-full h-full object-contain" alt="" />
                      <button onClick={() => removeImage(idx)} className="absolute inset-0 bg-red-600/90 text-white flex flex-col items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300">
                         <IconTrash size={24}/>
                         <span className="text-[8px] font-black uppercase mt-1">Excluir</span>
                      </button>
                    </div>
                  ))}
                  <button onClick={() => fileInputRef.current?.click()} className="aspect-square border-4 border-dashed border-gray-100 rounded-[28px] flex flex-col items-center justify-center text-gray-300 hover:text-blue-400 hover:border-blue-100 transition-all">
                     <IconPlus size={32}/>
                     <span className="text-[9px] font-black uppercase mt-2">Upload</span>
                  </button>
                </div>
              </section>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
                <section className="space-y-8">
                  <div className="space-y-6">
                    <h3 className="text-xs font-black text-blue-600 uppercase tracking-widest border-l-4 border-blue-600 pl-4">Dados Principais</h3>
                    <div className="space-y-4">
                       <input value={form.name} onChange={e => setForm({...form, name: e.target.value})} className="w-full bg-gray-50 border-none rounded-2xl p-5 text-sm font-bold shadow-inner" placeholder="Nome do Produto" />
                       <textarea value={form.description} onChange={e => setForm({...form, description: e.target.value})} className="w-full bg-gray-50 border-none rounded-2xl p-5 text-sm font-bold h-32 resize-none shadow-inner" placeholder="Descrição rápida..." />
                       
                       <div className="grid grid-cols-2 gap-6">
                        <input type="number" value={form.price} onChange={e => setForm({...form, price: Number(e.target.value)})} className="w-full bg-blue-50 border-none rounded-2xl p-5 text-sm font-black text-blue-700 shadow-inner" placeholder="Preço" />
                        <input type="number" value={form.oldPrice || ''} onChange={e => setForm({...form, oldPrice: Number(e.target.value)})} className="w-full bg-gray-50 border-none rounded-2xl p-5 text-sm font-bold shadow-inner" placeholder="Preço Antigo" />
                      </div>

                      <div className="p-6 bg-orange-50/50 rounded-[32px] border border-orange-100 space-y-3">
                        <h4 className="text-[10px] font-black text-orange-600 uppercase tracking-widest">Link de Checkout Direto (Hotmart/Stripe/etc)</h4>
                        <input value={form.checkoutLink || ''} onChange={e => setForm({...form, checkoutLink: e.target.value})} className="w-full bg-white border-none rounded-xl p-4 text-[11px] font-bold shadow-sm" placeholder="URL do link de pagamento externo..." />
                      </div>

                      <div className="space-y-3">
                        <h4 className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-2">Categoria do Produto</h4>
                        <select 
                          value={form.categoryId} 
                          onChange={e => setForm({...form, categoryId: e.target.value})} 
                          className="w-full bg-gray-50 border-none rounded-2xl p-5 text-sm font-bold shadow-inner appearance-none cursor-pointer"
                        >
                          {categories.map(c => <option key={c.id} value={c.id}>{c.icon} {c.name}</option>)}
                        </select>
                      </div>
                    </div>
                  </div>

                  <label className="flex items-center justify-between bg-gray-50 p-6 rounded-[32px] cursor-pointer group shadow-sm">
                    <span className="text-xs font-black uppercase group-hover:text-blue-600 transition-colors">Disponível no Estoque</span>
                    <input type="checkbox" checked={form.inStock} onChange={e => setForm({...form, inStock: e.target.checked})} className="w-7 h-7 rounded-xl border-gray-200 text-blue-600" />
                  </label>
                </section>

                <section className="space-y-12">
                  <div className="space-y-6">
                    <div className="flex items-center justify-between">
                       <h3 className="text-xs font-black text-purple-600 uppercase tracking-widest border-l-4 border-purple-600 pl-4">Variações (Tamanhos/Sabores)</h3>
                       <button onClick={addVariation} className="bg-purple-50 text-purple-600 px-4 py-2 rounded-xl text-[10px] font-black uppercase">+ Grupo</button>
                    </div>
                    {form.variations?.map((v, i) => (
                      <div key={v.id} className="bg-gray-50 p-6 rounded-[32px] border border-gray-100 space-y-4 animate-in slide-in-from-right-4">
                         <div className="flex items-center gap-4">
                            <input value={v.name} onChange={e => updateVariation(i, 'name', e.target.value)} className="flex-grow bg-white border-none rounded-xl p-4 text-[11px] font-black uppercase" placeholder="Ex: Sabor ou Tamanho" />
                            <button onClick={() => setForm({...form, variations: form.variations?.filter(x => x.id !== v.id)})} className="text-red-300 hover:text-red-500"><IconTrash size={18}/></button>
                         </div>
                         <input 
                           value={v.options.join(', ')} 
                           onChange={e => updateVariation(i, 'options', e.target.value.split(',').map(s => s.trim()).filter(Boolean))} 
                           className="w-full bg-white border-none rounded-xl p-4 text-[11px] font-bold" 
                           placeholder="Ex: P, M, G (separe por vírgula)" 
                         />
                      </div>
                    ))}
                  </div>
                </section>
              </div>
            </div>

            <footer className="p-10 border-t border-gray-50 bg-gray-50/50">
               <button onClick={handleSave} className="w-full bg-gray-900 text-white font-black py-7 rounded-[32px] uppercase text-xs tracking-[0.4em] shadow-2xl active:scale-[0.98] transition-all">
                 Publicar Produto Atualizado
               </button>
            </footer>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminCatalog;
