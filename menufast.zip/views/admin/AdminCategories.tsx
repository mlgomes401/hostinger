
import React, { useState } from 'react';
import { useApp } from '../../App';
import { Category } from '../../types';
import { IconPlus, IconTrash, IconArrowLeft } from '../../components/Icons';

const AdminCategories: React.FC = () => {
  const { categories, setCategories, showToast, confirmAction, products } = useApp();
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [form, setForm] = useState<Partial<Category>>({});

  const getProductCount = (categoryId: string) => {
    return products.filter(p => p.categoryId === categoryId).length;
  };

  const handleEdit = (c: Category | null) => {
    if (c) {
      setEditingCategory(c);
      setForm({ ...c });
    } else {
      const newId = 'cat' + Date.now();
      setEditingCategory({ id: newId } as any);
      setForm({
        id: newId,
        name: '',
        icon: '📦',
        order: categories.length,
        active: true
      });
    }
  };

  const handleSave = () => {
    if (!form.name?.trim()) return showToast('O nome é obrigatório', 'error');

    const catData = { ...form } as Category;
    const exists = categories.find(c => c.id === catData.id);

    if (!exists) {
      setCategories([...categories, catData]);
      showToast('Categoria criada!');
    } else {
      setCategories(categories.map(c => c.id === catData.id ? catData : c));
      showToast('Categoria atualizada!');
    }
    setEditingCategory(null);
  };

  const handleDelete = (id: string) => {
    const hasProducts = products.some(p => p.categoryId === id);
    if (hasProducts) {
      return showToast('Esta categoria possui produtos. Remova-os primeiro.', 'error');
    }

    confirmAction({
      title: 'Excluir Categoria?',
      message: 'Esta ação não pode ser desfeita.',
      onConfirm: () => {
        setCategories(categories.filter(c => c.id !== id));
        showToast('Categoria removida');
      }
    });
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-5">
        <div>
          <h1 className="text-3xl font-black uppercase tracking-tighter text-gray-900">Categorias</h1>
          <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-1">Estruture a navegação da sua loja</p>
        </div>
        <button 
          onClick={() => handleEdit(null)}
          className="bg-blue-600 text-white px-8 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-xl shadow-blue-100 flex items-center gap-2 active:scale-95 transition-all"
        >
          <IconPlus size={16} /> Nova Categoria
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {categories.sort((a,b) => (a.order || 0) - (b.order || 0)).map(cat => {
          const productCount = getProductCount(cat.id);
          return (
            <div key={cat.id} className="bg-white rounded-[32px] p-6 border border-gray-100 shadow-sm flex items-center justify-between group hover:shadow-md transition-all">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-gray-50 rounded-2xl flex items-center justify-center text-2xl shadow-inner">
                  {cat.icon || '📦'}
                </div>
                <div>
                  <h3 className="font-black text-gray-900 text-sm uppercase tracking-tight">{cat.name}</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <span className={`w-1.5 h-1.5 rounded-full ${cat.active ? 'bg-green-500' : 'bg-gray-300'}`} />
                    <span className="text-[9px] font-black text-gray-400 uppercase tracking-widest">
                      {cat.active ? 'Ativa' : 'Oculta'} • {productCount} {productCount === 1 ? 'Produto' : 'Produtos'}
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex gap-2">
                <button onClick={() => handleEdit(cat)} className="p-3 bg-gray-50 text-gray-400 rounded-xl hover:text-blue-600 hover:bg-blue-50 transition-all">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"/></svg>
                </button>
                <button onClick={() => handleDelete(cat.id)} className="p-3 bg-gray-50 text-gray-400 rounded-xl hover:text-red-600 hover:bg-red-50 transition-all">
                  <IconTrash size={18} />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {editingCategory && (
        <div className="fixed inset-0 z-[100] bg-black/70 backdrop-blur-xl flex items-center justify-center p-6 animate-in fade-in duration-300">
          <div className="bg-white w-full max-w-md rounded-[48px] overflow-hidden shadow-2xl animate-in zoom-in-95 duration-300">
            <header className="p-8 border-b border-gray-50 flex items-center justify-between">
              <div className="flex items-center gap-3">
                 <button onClick={() => setEditingCategory(null)} className="p-2 text-gray-400 hover:text-gray-900"><IconArrowLeft size={20}/></button>
                 <h2 className="text-xl font-black uppercase tracking-tighter">Categoria</h2>
              </div>
              <button onClick={handleSave} className="bg-blue-600 text-white px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-blue-100">Salvar</button>
            </header>
            
            <div className="p-8 space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-2">Nome da Categoria</label>
                <input 
                  value={form.name} 
                  onChange={e => setForm({...form, name: e.target.value})} 
                  className="w-full bg-gray-50 border-none rounded-2xl p-5 text-sm font-bold shadow-inner" 
                  placeholder="Ex: Suplementos, Acessórios..." 
                />
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-2">Emoji/Ícone</label>
                  <input 
                    value={form.icon} 
                    onChange={e => setForm({...form, icon: e.target.value})} 
                    className="w-full bg-gray-50 border-none rounded-2xl p-5 text-xl text-center shadow-inner" 
                    placeholder="⚡" 
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest px-2">Ordem</label>
                  <input 
                    type="number"
                    value={form.order} 
                    onChange={e => setForm({...form, order: Number(e.target.value)})} 
                    className="w-full bg-gray-50 border-none rounded-2xl p-5 text-sm font-black shadow-inner" 
                    placeholder="0" 
                  />
                </div>
              </div>

              <label className="flex items-center justify-between bg-gray-50 p-6 rounded-3xl cursor-pointer group transition-all hover:bg-blue-50">
                <div className="flex flex-col">
                  <span className="text-xs font-black uppercase tracking-tight">Categoria Ativa</span>
                  <span className="text-[9px] text-gray-400 font-bold uppercase">Aparece no menu do cliente?</span>
                </div>
                <input 
                  type="checkbox" 
                  checked={form.active} 
                  onChange={e => setForm({...form, active: e.target.checked})} 
                  className="w-6 h-6 rounded-lg border-gray-200 text-blue-600 focus:ring-blue-500" 
                />
              </label>
            </div>

            <footer className="p-8 bg-gray-50 flex gap-4">
               <button onClick={() => setEditingCategory(null)} className="flex-grow py-4 rounded-2xl text-[10px] font-black uppercase text-gray-400">Cancelar</button>
               <button onClick={handleSave} className="flex-grow bg-gray-900 text-white py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest">Confirmar Tudo</button>
            </footer>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminCategories;
