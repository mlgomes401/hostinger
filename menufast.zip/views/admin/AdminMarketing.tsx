
import React, { useRef, useEffect } from 'react';
import { useApp } from '../../App';

const AdminMarketing: React.FC = () => {
  const { config, showToast } = useApp();
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const drawStory = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Background
    const gradient = ctx.createLinearGradient(0, 0, 0, 1920);
    gradient.addColorStop(0, '#f8fafc');
    gradient.addColorStop(1, '#e2e8f0');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 1080, 1920);

    // Shape decoration
    ctx.fillStyle = '#3b82f6';
    ctx.beginPath();
    ctx.roundRect(50, 50, 980, 1820, 40);
    ctx.fill();

    ctx.fillStyle = '#ffffff';
    ctx.beginPath();
    ctx.roundRect(70, 70, 940, 1780, 30);
    ctx.fill();

    // Text
    ctx.fillStyle = '#1e293b';
    ctx.font = 'bold 80px Inter, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('PEÇA PELO NOSSO', 540, 400);
    ctx.fillText('CARDÁPIO DIGITAL', 540, 500);

    ctx.fillStyle = '#3b82f6';
    ctx.font = 'black 120px Inter, sans-serif';
    ctx.fillText(config.name.toUpperCase(), 540, 700);

    ctx.fillStyle = '#64748b';
    ctx.font = '40px Inter, sans-serif';
    ctx.fillText('Rápido, Prático e Seguro', 540, 800);

    // Call to Action
    ctx.fillStyle = '#ef4444';
    ctx.beginPath();
    ctx.roundRect(240, 1600, 600, 140, 70);
    ctx.fill();
    
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 50px Inter, sans-serif';
    ctx.fillText('CLIQUE NO LINK', 540, 1685);
  };

  useEffect(() => {
    drawStory();
  }, [config]);

  const download = () => {
    const link = document.createElement('a');
    link.download = `story-${config.name.toLowerCase().replace(/\s+/g, '-')}.png`;
    link.href = canvasRef.current?.toDataURL() || '';
    link.click();
    showToast('Arquivo pronto para download!', 'success');
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    showToast('Legenda copiada!', 'info');
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <h1 className="text-2xl font-black">Marketing</h1>
      <p className="text-gray-500">Gere artes rápidas para suas redes sociais.</p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 flex flex-col items-center">
           <h3 className="font-bold mb-4">Arte para Story (1080x1920)</h3>
           <div className="w-full max-w-[200px] border rounded-lg overflow-hidden mb-6 shadow-xl aspect-[9/16] bg-gray-50">
              <canvas ref={canvasRef} width="1080" height="1920" className="w-full h-auto" />
           </div>
           <button onClick={download} className="bg-blue-600 text-white font-black px-8 py-3 rounded-2xl text-xs uppercase tracking-widest shadow-lg shadow-blue-100 active:scale-95 transition-all">
             Baixar PNG
           </button>
        </div>

        <div className="bg-white rounded-3xl p-6 shadow-sm border border-gray-100">
           <h3 className="font-bold mb-4">Legendas Prontas</h3>
           <div className="space-y-4">
             {[
               "Bateu aquela fome? 🍔 Peça agora pelo nosso cardápio digital e receba no conforto da sua casa! Link na bio.",
               "Novidades fresquinhas no menu! 🌟 Confira os lançamentos da semana e aproveite nossos preços especiais."
             ].map((caption, i) => (
               <div key={i} className="p-4 bg-gray-50 rounded-2xl border border-gray-100 group">
                 <p className="text-sm text-gray-700 italic mb-3 leading-relaxed">"{caption}"</p>
                 <button 
                   onClick={() => copyToClipboard(caption)}
                   className="text-[10px] text-blue-600 font-black uppercase tracking-widest bg-white px-3 py-1.5 rounded-lg border border-blue-100 group-hover:bg-blue-600 group-hover:text-white transition-all"
                 >
                   Copiar Legenda
                 </button>
               </div>
             ))}
           </div>
        </div>
      </div>
    </div>
  );
};

export default AdminMarketing;
