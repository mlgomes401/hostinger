
import React, { useState } from 'react';
import { storage } from '../../services/storage';
import { Order, OrderStatus } from '../../types';
import { IconWhatsApp, IconTrash } from '../../components/Icons';
import { useApp } from '../../App';

const AdminOrders: React.FC = () => {
  const { showToast, confirmAction } = useApp();
  const [orders, setOrders] = useState<Order[]>(storage.getOrders());

  const updateStatus = (id: string, status: OrderStatus) => {
    const updated = orders.map(o => o.id === id ? { ...o, status } : o);
    setOrders(updated);
    storage.setOrders(updated);
    showToast(`Status atualizado para: ${statusMap[status]?.label || status}`, 'info');
  };

  const deleteOrder = (id: string) => {
    confirmAction({
      title: 'Excluir Registro?',
      message: 'Esta ação removerá o pedido permanentemente do histórico.',
      onConfirm: () => {
        const updated = orders.filter(o => o.id !== id);
        setOrders(updated);
        storage.setOrders(updated);
        showToast('Pedido removido com sucesso.', 'info');
      }
    });
  };

  const statusMap: Record<OrderStatus, { label: string, color: string }> = {
    new: { label: 'Novo', color: 'bg-red-50 text-red-600 border-red-100' },
    confirmed: { label: 'Confirmado', color: 'bg-blue-50 text-blue-600 border-blue-100' },
    preparing: { label: 'Preparando', color: 'bg-yellow-50 text-yellow-600 border-yellow-100' },
    shipped: { label: 'Em Rota', color: 'bg-purple-50 text-purple-600 border-purple-100' },
    delivered: { label: 'Entregue', color: 'bg-green-50 text-green-600 border-green-100' },
    cancelled: { label: 'Cancelado', color: 'bg-gray-100 text-gray-500 border-gray-200' },
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-black uppercase tracking-tighter">Gestão de Pedidos</h1>
        <div className="bg-blue-600 text-white px-5 py-2 rounded-2xl text-[10px] font-black uppercase tracking-widest">
          {orders.length} TOTAL
        </div>
      </div>
      
      <div className="space-y-6">
        {orders.length === 0 && (
          <div className="text-center py-32 bg-white rounded-[44px] border border-gray-100 shadow-sm">
            <p className="text-gray-400 font-black uppercase text-[10px] tracking-[0.3em]">Nenhum pedido registrado.</p>
          </div>
        )}
        {orders.map(order => {
          const s = statusMap[order.status] || statusMap.new;
          return (
            <div key={order.id} className="bg-white rounded-[40px] p-8 shadow-sm border border-gray-100 hover:shadow-md transition-all">
              <div className="flex justify-between items-start mb-6">
                <div className="flex gap-4 items-center">
                  <div className="w-14 h-14 bg-gray-50 rounded-2xl flex items-center justify-center font-black text-xs text-gray-400 border border-gray-100">
                    #{order.id}
                  </div>
                  <div>
                    <h3 className="text-lg font-black text-gray-900 uppercase tracking-tight leading-none mb-1">{order.customerName}</h3>
                    <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">{order.customerPhone}</p>
                  </div>
                </div>
                <div className={`px-5 py-2 rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] border ${s.color}`}>
                  {s.label}
                </div>
              </div>

              <div className="bg-gray-50 rounded-[32px] p-6 mb-6 space-y-3 border border-gray-100">
                 <div className="flex items-center justify-between">
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Valor do Pedido</span>
                    <span className="font-black text-blue-600 text-xl tracking-tighter">R$ {order.total.toFixed(2)}</span>
                 </div>
                 <div className="flex flex-wrap gap-2 pt-2 border-t border-gray-200/50">
                    <span className="text-[9px] font-black text-gray-400 uppercase">{order.items.length} itens</span>
                    <span className="text-[9px] font-black text-gray-300">•</span>
                    <span className="text-[9px] font-black text-gray-400 uppercase">{new Date(order.createdAt).toLocaleDateString()}</span>
                 </div>
              </div>

              <div className="flex flex-wrap gap-2">
                {Object.keys(statusMap).map(statusKey => (
                  <button 
                    key={statusKey}
                    onClick={() => updateStatus(order.id, statusKey as OrderStatus)}
                    className={`px-4 py-2.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all active:scale-95 ${order.status === statusKey ? 'bg-gray-900 text-white shadow-lg' : 'bg-gray-50 text-gray-400 hover:bg-gray-100'}`}
                  >
                    {statusMap[statusKey as OrderStatus].label}
                  </button>
                ))}
                <div className="flex-grow" />
                <div className="flex gap-2">
                  <button 
                    onClick={() => deleteOrder(order.id)}
                    className="bg-red-50 text-red-500 p-3 rounded-xl flex items-center justify-center active:scale-90 hover:bg-red-500 hover:text-white transition-all"
                  >
                    <IconTrash size={18}/>
                  </button>
                  <button 
                    onClick={() => window.open(`https://wa.me/${order.customerPhone.replace(/\D/g,'')}`, '_blank')}
                    className="bg-green-500 text-white p-3 rounded-xl flex items-center justify-center active:scale-90 shadow-lg shadow-green-100"
                  >
                    <IconWhatsApp size={18}/>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default AdminOrders;
