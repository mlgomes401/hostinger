
import React from 'react';
import { useApp } from '../../App';
import { storage } from '../../services/storage';
import { useNavigate } from 'react-router-dom';
import { IconChevronRight } from '../../components/Icons';

const AdminDashboard: React.FC = () => {
  const { config, setConfig } = useApp();
  const navigate = useNavigate();
  const orders = storage.getOrders();

  const stats = [
    { label: 'Pedidos Hoje', value: orders.filter(o => new Date(o.createdAt).toDateString() === new Date().toDateString()).length },
    { label: 'Vendas Totais', value: `R$ ${orders.reduce((acc,o) => acc+o.total, 0).toFixed(2)}` },
    { label: 'Novos Pedidos', value: orders.filter(o => o.status === 'new').length },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-black tracking-tighter uppercase">Dashboard</h1>
          <p className="text-gray-500 text-xs font-bold uppercase tracking-tight">Centro de controle: {config.name}</p>
        </div>
        <div className="flex items-center gap-4 bg-white px-6 py-4 rounded-3xl shadow-sm border border-gray-100">
           <span className="text-[10px] font-black uppercase tracking-widest text-gray-500">Status da Loja: <span className={config.isOpen ? 'text-green-500' : 'text-red-500'}>{config.isOpen ? 'ABERTA' : 'FECHADA'}</span></span>
           <button 
             onClick={() => setConfig({ ...config, isOpen: !config.isOpen })}
             className={`w-14 h-7 rounded-full transition-all relative ${config.isOpen ? 'bg-green-500 shadow-lg shadow-green-100' : 'bg-gray-200'}`}
           >
             <div className={`absolute top-1 w-5 h-5 bg-white rounded-full transition-all shadow-sm ${config.isOpen ? 'right-1' : 'left-1'}`} />
           </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stats.map((s, idx) => (
          <div key={idx} className="bg-white p-8 rounded-[40px] shadow-sm border border-gray-100 relative overflow-hidden group">
            <div className="absolute top-0 right-0 w-24 h-24 bg-blue-50/50 rounded-full -mr-10 -mt-10 transition-transform group-hover:scale-110" />
            <p className="text-gray-400 text-[10px] font-black uppercase tracking-[0.2em] mb-2 relative z-10">{s.label}</p>
            <p className="text-3xl font-black text-gray-900 tracking-tighter relative z-10">{s.value}</p>
          </div>
        ))}
      </div>

      <div className="bg-white rounded-[44px] p-10 shadow-sm border border-gray-100">
        <div className="flex items-center justify-between mb-8">
          <h3 className="font-black text-lg uppercase tracking-tight">Pedidos Recentes</h3>
          <button 
            onClick={() => navigate('/admin/pedidos')}
            className="text-[10px] font-black text-blue-600 uppercase tracking-widest flex items-center gap-1 hover:gap-2 transition-all"
          >
            Ver todos <IconChevronRight size={14} />
          </button>
        </div>
        
        {orders.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-gray-400 text-xs font-bold uppercase tracking-widest">Nenhum pedido realizado ainda.</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-50">
            {orders.slice(0, 5).map(order => (
              <div key={order.id} className="py-5 flex justify-between items-center group cursor-pointer" onClick={() => navigate('/admin/pedidos')}>
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-gray-50 rounded-2xl flex items-center justify-center font-black text-xs text-gray-400 uppercase">
                    #{order.id}
                  </div>
                  <div>
                    <p className="font-black text-gray-900 text-sm uppercase">{order.customerName}</p>
                    <p className="text-[10px] text-gray-400 font-bold uppercase">{new Date(order.createdAt).toLocaleTimeString([], {hour:'2-digit', minute:'2-digit'})} • {order.items.length} itens</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-black text-blue-600 text-sm tracking-tight">R$ {order.total.toFixed(2)}</p>
                  <span className="text-[9px] px-3 py-1 rounded-full bg-blue-50 text-blue-600 font-black uppercase tracking-widest">
                    {order.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;
