
import React, { useState, useRef } from 'react';
import { useApp } from '../../App';
import { INITIAL_CONFIG } from '../../constants';
import { IconPlus, IconTrash } from '../../components/Icons';
import { Theme } from '../../types';

const AdminSettings: React.FC = () => {
  const { config, setConfig, showToast, confirmAction } = useApp();
  const [isProcessing, setIsProcessing] = useState(false);
  
  const logoInputRef = useRef<HTMLInputElement>(null);
  const bannerInputRef = useRef<HTMLInputElement>(null);
  const popupInputRef = useRef<HTMLInputElement>(null);

  const themes: { id: Theme, label: string, color: string, border: string }[] = [
    { id: 'light', label: 'Claro', color: 'bg-white', border: 'border-gray-200' },
    { id: 'dark', label: 'Escuro', color: 'bg-gray-900', border: 'border-gray-700' },
    { id: 'food', label: 'Food', color: 'bg-orange-50', border: 'border-orange-200' },
    { id: 'tech', label: 'Tech', color: 'bg-slate-100', border: 'border-slate-300' },
  ];

  const handleUpdate = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    if (type === 'checkbox') {
      const { checked } = e.target as HTMLInputElement;
      setConfig({ ...config, [name]: checked });
    } else {
      setConfig({ ...config, [name]: value });
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>, type: 'logo' | 'banner' | 'popupImage') => {
    if (!e.target.files?.length) return;
    setIsProcessing(true);
    showToast('Processando mídia...', 'info');
    try {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (ev) => {
        setConfig({ ...config, [type]: ev.target?.result as string });
        showToast(`${type.toUpperCase()} atualizado!`, 'success');
        setIsProcessing(false);
      };
    } catch (err) {
      showToast('Erro no processamento da imagem.', 'error');
      setIsProcessing(false);
    }
  };

  const saveSettings = () => {
    if (!config.name.trim()) return showToast('O nome da loja é obrigatório', 'error');
    setIsProcessing(true);
    setTimeout(() => {
      setIsProcessing(false);
      showToast('Configurações atualizadas! ✅', 'success');
    }, 600);
  };

  const handleReset = () => {
    confirmAction({
      title: 'Resetar Tudo?',
      message: 'Esta ação voltará as configurações originais da loja.',
      onConfirm: () => {
        setConfig(INITIAL_CONFIG);
        showToast('Configurações resetadas com sucesso', 'info');
      }
    });
  };

  return (
    <div className="max-w-2xl space-y-8 pb-20">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-black">Configurações</h1>
        <button onClick={handleReset} className="text-[10px] font-black text-red-400 uppercase tracking-widest">Redefinir Padrões</button>
      </div>

      <div className="bg-white rounded-[40px] p-8 shadow-sm border border-gray-100 space-y-8">
        <section className="space-y-4">
          <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-widest border-l-4 border-blue-600 pl-4">Logística e Checkout</h3>
          
          <div className="flex items-center justify-between p-5 bg-gray-50 rounded-2xl">
             <div className="flex flex-col">
               <span className="text-xs font-black uppercase tracking-tight">Taxa de Entrega Fixa</span>
               <span className="text-[9px] text-gray-400 font-bold uppercase">Ativa cobrança no carrinho</span>
             </div>
             <button onClick={() => setConfig({...config, enableDeliveryFee: !config.enableDeliveryFee})} className={`w-12 h-6 rounded-full relative transition-all ${config.enableDeliveryFee ? 'bg-blue-600' : 'bg-gray-300'}`}>
                <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${config.enableDeliveryFee ? 'right-1' : 'left-1'}`} />
             </button>
          </div>

          {config.enableDeliveryFee && (
            <div className="animate-in slide-in-from-top-2">
               <input type="number" name="deliveryFee" value={config.deliveryFee} onChange={(e) => setConfig({...config, deliveryFee: Number(e.target.value)})} className="w-full bg-gray-50 border-none rounded-2xl p-5 font-black text-blue-600 text-lg shadow-inner" placeholder="0.00" />
            </div>
          )}

          <div className="flex items-center justify-between p-5 bg-gray-50 rounded-2xl mt-4">
             <div className="flex flex-col">
               <span className="text-xs font-black uppercase tracking-tight">Checkout Global (Link)</span>
               <span className="text-[9px] text-gray-400 font-bold uppercase">Usa um link externo p/ pagamento</span>
             </div>
             <button onClick={() => setConfig({...config, enableCheckoutUrl: !config.enableCheckoutUrl})} className={`w-12 h-6 rounded-full relative transition-all ${config.enableCheckoutUrl ? 'bg-blue-600' : 'bg-gray-300'}`}>
                <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${config.enableCheckoutUrl ? 'right-1' : 'left-1'}`} />
             </button>
          </div>

          {config.enableCheckoutUrl && (
             <div className="animate-in slide-in-from-top-2 space-y-2">
               <input name="checkoutUrl" value={config.checkoutUrl} onChange={handleUpdate} className="w-full bg-gray-50 border-none rounded-2xl p-5 text-xs font-bold" placeholder="URL: Ex: stripe.com/checkout..." />
               <p className="text-[8px] text-gray-400 font-bold uppercase px-2">Link padrão para itens sem checkout individual.</p>
             </div>
          )}
        </section>

        <section className="space-y-6">
           <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-widest border-l-4 border-blue-600 pl-4">Identidade da Loja</h3>
           <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-gray-50 rounded-3xl flex flex-col items-center gap-3 border border-dashed border-gray-200">
                 <span className="text-[9px] font-black text-gray-400 uppercase">Logo Principal</span>
                 {/* PREVIEW DA LOGO AUMENTADO PARA w-24 h-24 */}
                 <div className="w-24 h-24 bg-white rounded-2xl shadow-sm overflow-hidden flex items-center justify-center p-2 relative group">
                    <img src={config.logo} className="w-full h-full object-contain" />
                    <button onClick={() => logoInputRef.current?.click()} className="absolute inset-0 bg-black/40 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"><IconPlus size={20}/></button>
                 </div>
                 <input ref={logoInputRef} type="file" className="hidden" onChange={(e) => handleImageUpload(e, 'logo')} />
              </div>
              <div className="p-4 bg-gray-50 rounded-3xl flex flex-col items-center gap-3 border border-dashed border-gray-200">
                 <span className="text-[9px] font-black text-gray-400 uppercase">Banner Menu</span>
                 <div className="w-32 h-20 bg-white rounded-2xl shadow-sm overflow-hidden flex items-center justify-center relative group">
                    <img src={config.banner} className="w-full h-full object-cover" />
                    <button onClick={() => bannerInputRef.current?.click()} className="absolute inset-0 bg-black/40 text-white flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"><IconPlus size={20}/></button>
                 </div>
                 <input ref={bannerInputRef} type="file" className="hidden" onChange={(e) => handleImageUpload(e, 'banner')} />
              </div>
           </div>
           <input name="name" value={config.name} onChange={handleUpdate} className="w-full bg-gray-50 border-none rounded-2xl p-5 font-bold text-sm" placeholder="Nome da Loja" />
           <input name="whatsapp" value={config.whatsapp} onChange={handleUpdate} className="w-full bg-gray-50 border-none rounded-2xl p-5 font-bold text-sm" placeholder="Whats: 1199999999" />
        </section>
      </div>

      <button onClick={saveSettings} disabled={isProcessing} className="w-full bg-blue-600 text-white font-black py-8 rounded-[32px] shadow-2xl active:scale-95 transition-all text-xs uppercase tracking-widest">
        {isProcessing ? 'Sincronizando...' : 'SALVAR TODAS AS ALTERAÇÕES'}
      </button>
    </div>
  );
};

export default AdminSettings;
