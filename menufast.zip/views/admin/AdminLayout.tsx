
import React from 'react';
import { Outlet, useNavigate, useLocation, Link } from 'react-router-dom';
import { IconHome } from '../../components/Icons';

const AdminLayout: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const menu = [
    { label: 'Painel', path: '/admin' },
    { label: 'Catálogo', path: '/admin/catalogo' },
    { label: 'Categorias', path: '/admin/categorias' },
    { label: 'Pedidos', path: '/admin/pedidos' },
    { label: 'Marketing', path: '/admin/marketing' },
    { label: 'Config', path: '/admin/config' },
  ];

  const isActive = (path: string) => {
    if (path === '/admin') {
      return location.pathname === '/admin' || location.pathname === '/admin/';
    }
    return location.pathname === path;
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col lg:flex-row">
      {/* Sidebar / Top Nav */}
      <aside className="lg:w-64 bg-white border-b lg:border-r border-gray-200 sticky top-0 lg:h-screen z-50 shadow-sm">
        <div className="p-6 hidden lg:flex flex-col gap-4 border-b border-gray-50 mb-2">
          <h2 className="text-xl font-black text-blue-600">Saúde Suplementa <span className="text-gray-400 font-medium text-[10px] block uppercase tracking-widest mt-1">Admin Panel</span></h2>
          <button 
            onClick={() => navigate('/')}
            className="flex items-center gap-2 bg-blue-50 text-blue-600 px-4 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-blue-100 transition-all"
          >
            <IconHome size={14} /> Ver Cardápio
          </button>
        </div>
        
        {/* Mobile Header */}
        <div className="lg:hidden flex items-center justify-between p-4 bg-white border-b border-gray-100">
           <div className="flex flex-col">
             <span className="font-black text-blue-600 text-sm">Saúde Suplementa</span>
             <span className="text-[9px] text-gray-400 font-bold uppercase tracking-widest">Gestão de Vendas</span>
           </div>
           <button 
             onClick={() => navigate('/')}
             className="flex items-center gap-2 bg-red-50 text-red-600 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest active:scale-95 transition-all"
           >
             <IconHome size={14} /> Sair
           </button>
        </div>

        <nav className="flex lg:flex-col p-2 lg:p-4 gap-2 overflow-x-auto lg:overflow-x-visible no-scrollbar">
          {menu.map(item => (
            <Link
              key={item.path}
              to={item.path}
              className={`whitespace-nowrap flex-1 lg:flex-none text-left px-5 py-4 rounded-2xl text-[11px] font-black uppercase tracking-widest transition-all ${
                isActive(item.path)
                ? 'bg-blue-600 text-white shadow-xl shadow-blue-100' 
                : 'text-gray-500 hover:bg-gray-50 border border-transparent'
              }`}
            >
              {item.label}
            </Link>
          ))}
        </nav>
      </aside>

      <main className="flex-1 p-4 lg:p-10 max-w-6xl mx-auto w-full pb-24 lg:pb-10">
        <Outlet />
      </main>
    </div>
  );
};

export default AdminLayout;
