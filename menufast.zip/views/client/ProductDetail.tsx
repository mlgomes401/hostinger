
import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useApp } from '../../App';
import { IconPlus, IconMinus, IconPix, IconArrowLeft, IconCart } from '../../components/Icons';

const ProductDetail: React.FC = () => {
  const { id } = useParams();
  const { products, config, addToCart, showToast } = useApp();
  const navigate = useNavigate();
  const scrollRef = useRef<HTMLDivElement>(null);
  const product = products.find(p => p.id === id);

  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [qty, setQty] = useState(1);
  const [selectedVariations, setSelectedVariations] = useState<Record<string, string>>({});
  const [added, setAdded] = useState(false);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [id]);

  if (!product) return (
    <div className="flex flex-col items-center justify-center min-h-screen text-center p-10 bg-white">
      <h2 className="text-xl font-black mb-4 tracking-tighter text-gray-900 uppercase">Produto não encontrado</h2>
      <button onClick={() => navigate('/')} className="bg-blue-600 text-white px-8 py-4 rounded-2xl font-black uppercase text-[10px] tracking-widest">VOLTAR AO CARDÁPIO</button>
    </div>
  );

  const images = product.images && product.images.length > 0 ? product.images : ['https://placehold.co/600x600?text=Sem+Imagem'];
  const savings = product.oldPrice ? (product.oldPrice - product.price) : 0;

  const handleScroll = () => {
    if (scrollRef.current) {
      const index = Math.round(scrollRef.current.scrollLeft / scrollRef.current.offsetWidth);
      setCurrentImageIndex(index);
    }
  };

  const scrollToImage = (idx: number) => {
    if (scrollRef.current) {
      scrollRef.current.scrollTo({
        left: idx * scrollRef.current.offsetWidth,
        behavior: 'smooth'
      });
    }
  };

  const validateSelections = () => {
    const missing = product.variations.filter(g => g.required && !selectedVariations[g.id]);
    if (missing.length > 0) {
      showToast(`Escolha obrigatória: ${missing.map(m => m.name).join(', ')}`, 'error');
      return false;
    }
    return true;
  };

  const handleAddToCart = () => {
    if (!validateSelections()) return;
    addToCart({ 
      cartId: 'c'+Date.now(), 
      productId: product.id, 
      quantity: qty, 
      selectedVariations, 
      selectedExtras: [], 
      observation: '' 
    });
    setAdded(true);
  };

  const handleDirectPurchase = () => {
    if (!validateSelections()) return;
    if (product.checkoutLink) {
      window.open(product.checkoutLink.startsWith('http') ? product.checkoutLink : `https://${product.checkoutLink}`, '_blank');
    } else if (config.checkoutUrl) {
      window.open(config.checkoutUrl.startsWith('http') ? config.checkoutUrl : `https://${config.checkoutUrl}`, '_blank');
    } else {
      showToast('Finalize pela sacola via WhatsApp.', 'info');
      handleAddToCart();
      navigate('/carrinho');
    }
  };

  return (
    <div className="pb-60 bg-white min-h-screen animate-in fade-in duration-500 overflow-x-hidden">
      {/* HEADER NAVEGAÇÃO */}
      <div className="fixed top-0 inset-x-0 z-50 p-5 flex justify-between items-center pointer-events-none">
        <button onClick={() => navigate(-1)} className="pointer-events-auto bg-white/90 backdrop-blur-md p-3.5 rounded-2xl shadow-xl border border-gray-100 active:scale-90 transition-all">
          <IconArrowLeft size={20} className="text-gray-900" />
        </button>
        <button onClick={() => navigate('/carrinho')} className="pointer-events-auto bg-white/90 backdrop-blur-md p-3.5 rounded-2xl shadow-xl border border-gray-100 active:scale-90 transition-all relative">
          <IconCart size={20} className="text-gray-900" />
          {added && <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full border-2 border-white animate-ping" />}
        </button>
      </div>

      {/* CARROSSEL DE IMAGENS - SWIPE NATIVO */}
      <div className="bg-gray-50 pt-20 pb-12 relative border-b border-gray-100">
        <div 
          ref={scrollRef}
          onScroll={handleScroll}
          className="flex overflow-x-auto snap-x snap-mandatory no-scrollbar cursor-grab active:cursor-grabbing"
        >
          {images.map((img, idx) => (
            <div key={idx} className="w-full flex-shrink-0 snap-center flex justify-center items-center px-8 h-80">
              <img 
                src={img} 
                className="max-w-full max-h-full object-contain drop-shadow-2xl" 
                alt={`${product.name} - ${idx + 1}`} 
              />
            </div>
          ))}
        </div>

        {images.length > 1 && (
          <div className="absolute bottom-6 inset-x-0 flex justify-center gap-2.5">
            {images.map((_, idx) => (
              <button 
                key={idx}
                onClick={() => scrollToImage(idx)}
                className={`transition-all duration-300 rounded-full ${currentImageIndex === idx ? 'w-10 bg-blue-600 h-2' : 'w-2 bg-gray-300 h-2'}`}
              />
            ))}
          </div>
        )}
      </div>

      <div className="p-8 space-y-10 max-w-xl mx-auto bg-white rounded-t-[48px] -mt-10 shadow-[0_-20px_40px_rgba(0,0,0,0.03)] relative z-10">
        <div className="text-center space-y-4">
          <div className="flex justify-center gap-2">
            <span className="bg-gray-900 text-white text-[9px] font-black px-4 py-1.5 rounded-full uppercase tracking-widest">Produto Original</span>
            {savings > 0 && <span className="bg-green-600 text-white text-[9px] font-black px-4 py-1.5 rounded-full uppercase tracking-widest">Oferta Ativa</span>}
          </div>
          
          <h1 className="text-3xl font-black text-gray-900 uppercase tracking-tighter leading-none">{product.name}</h1>
          
          <div className="flex flex-col items-center bg-blue-50/50 py-6 rounded-[32px] border border-blue-50">
             <div className="flex items-center gap-3">
                <span className="text-4xl font-black text-blue-600 tracking-tighter">R$ {product.price.toFixed(2)}</span>
                {product.oldPrice && <span className="text-sm font-bold text-gray-300 line-through">R$ {product.oldPrice.toFixed(2)}</span>}
             </div>
             {savings > 0 && <span className="text-[10px] font-black text-green-600 uppercase tracking-widest mt-2">Você economiza R$ {savings.toFixed(2)} nesta compra</span>}
          </div>

          <p className="text-gray-500 text-sm font-medium leading-relaxed max-w-sm mx-auto">{product.description}</p>
        </div>

        {/* VARIAÇÕES */}
        {product.variations.length > 0 && (
          <div className="space-y-6">
            {product.variations.map(group => (
              <div key={group.id} className="space-y-4">
                <div className="flex justify-between items-center px-1">
                  <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-widest">{group.name}</h3>
                  {group.required && <span className="text-[8px] font-black text-red-500 uppercase">Selecione uma opção</span>}
                </div>
                <div className="grid grid-cols-2 gap-3">
                   {group.options.map(opt => (
                     <button 
                       key={opt}
                       onClick={() => { setSelectedVariations({...selectedVariations, [group.id]: opt}); setAdded(false); }}
                       className={`py-5 px-2 rounded-2xl border-2 text-[10px] font-black uppercase tracking-widest transition-all ${selectedVariations[group.id] === opt ? 'bg-blue-600 border-blue-600 text-white shadow-xl scale-[1.02]' : 'bg-gray-50 border-transparent text-gray-400'}`}
                     >
                       {opt}
                     </button>
                   ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* RODAPÉ DE CHECKOUT DIRETO */}
      <div className="fixed bottom-0 inset-x-0 bg-white/95 backdrop-blur-xl border-t border-gray-100 p-6 z-50 shadow-[0_-20px_50px_rgba(0,0,0,0.1)]">
        <div className="max-w-xl mx-auto space-y-4">
          <div className="flex gap-3">
            <div className="flex items-center bg-gray-100 rounded-2xl p-1 w-32">
               <button onClick={() => {setQty(q => Math.max(1, q-1)); setAdded(false);}} className="w-9 h-9 flex items-center justify-center bg-white rounded-xl shadow-sm active:scale-90 transition-all text-gray-400"><IconMinus size={14}/></button>
               <span className="flex-grow text-center font-black text-sm">{qty}</span>
               <button onClick={() => {setQty(q => q+1); setAdded(false);}} className="w-9 h-9 flex items-center justify-center bg-white rounded-xl shadow-sm active:scale-90 transition-all text-blue-600"><IconPlus size={14}/></button>
            </div>
            
            <button 
              onClick={handleAddToCart} 
              className={`flex-grow font-black rounded-2xl py-4 uppercase text-[10px] tracking-widest transition-all ${added ? 'bg-green-600 text-white' : 'bg-gray-900 text-white hover:bg-gray-800'}`}
            >
               {added ? 'ADICIONADO! ✅' : 'ADC. À SACOLA'}
            </button>
          </div>

          <button 
            onClick={handleDirectPurchase}
            className="w-full bg-blue-600 text-white font-black py-6 rounded-[28px] text-[12px] uppercase tracking-[0.25em] shadow-2xl shadow-blue-200 active:scale-[0.98] transition-all flex items-center justify-center gap-3 relative overflow-hidden group"
          >
            <div className="absolute inset-0 bg-white/10 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 skew-x-12"></div>
            <IconPix size={22} /> FINALIZAR COMPRA AGORA
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
