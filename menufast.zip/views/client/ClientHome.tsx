
import React, { useState, useMemo, useEffect } from 'react';
import { useApp } from '../../App';
import { useNavigate } from 'react-router-dom';
import { IconSearch, IconCart, IconHome, IconUser, IconPlus, IconList, IconWhatsApp, IconMinus } from '../../components/Icons';
import { Product } from '../../types';

interface PromoPopupProps {
  config: any;
  onClose: () => void;
}

const PromoPopup: React.FC<PromoPopupProps> = ({ config, onClose }) => {
  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-6">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-md animate-in fade-in duration-500" onClick={onClose} />
      <div className="relative bg-white w-full max-w-sm rounded-[44px] overflow-hidden animate-in zoom-in-95 duration-500 shadow-[0_32px_64px_rgba(0,0,0,0.4)]">
        <button 
          onClick={onClose}
          className="absolute top-6 right-6 z-10 bg-white/20 backdrop-blur-md text-white p-2 rounded-full active:scale-90 transition-all border border-white/20"
        >
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><path d="M18 6 6 18M6 6l12 12"/></svg>
        </button>

        {config.popupImage && (
          <div className="h-64 w-full relative">
            <img src={config.popupImage} className="w-full h-full object-cover" alt="Promoção" />
            <div className="absolute inset-0 bg-gradient-to-t from-white via-transparent to-transparent" />
          </div>
        )}

        <div className="p-10 pt-4 text-center space-y-4">
          <h2 className="text-2xl font-black text-gray-900 tracking-tighter uppercase leading-tight">{config.popupTitle}</h2>
          <p className="text-gray-500 text-sm font-bold leading-relaxed uppercase tracking-tight">{config.popupDescription}</p>
          <button 
            onClick={onClose}
            className="w-full bg-blue-600 text-white font-black py-5 rounded-2xl shadow-xl shadow-blue-100 uppercase text-[10px] tracking-[0.2em] active:scale-95 transition-all mt-4"
          >
            {config.popupButtonText || 'Aproveitar Agora'}
          </button>
        </div>
      </div>
    </div>
  );
};

interface QuickAddProps {
  product: Product;
  onClose: () => void;
  onAdd: (qty: number, variations: Record<string, string>, extras: string[], obs: string) => void;
  themeColor: string;
}

const QuickAddBottomSheet: React.FC<QuickAddProps> = ({ product, onClose, onAdd, themeColor }) => {
  const [qty, setQty] = useState(1);
  const [selections, setSelections] = useState<Record<string, string>>({});
  const [selectedExtras, setSelectedExtras] = useState<string[]>([]);
  const [obs, setObs] = useState('');

  const currentTotal = useMemo(() => {
    const base = Number(product.price);
    const extrasTotal = product.extras
      .filter(e => selectedExtras.includes(e.id))
      .reduce((acc, curr) => acc + Number(curr.price), 0);
    return (base + extrasTotal) * qty;
  }, [product, selectedExtras, qty]);

  const missingRequired = useMemo(() => {
    return product.variations.filter(v => v.required && !selections[v.id]);
  }, [product, selections]);

  const isReady = missingRequired.length === 0;

  const toggleExtra = (id: string) => {
    setSelectedExtras(prev => 
      prev.includes(id) ? prev.filter(e => e !== id) : [...prev, id]
    );
  };

  return (
    <div className="fixed inset-0 z-[110] flex items-end justify-center">
      <div className="absolute inset-0 bg-black/70 backdrop-blur-sm animate-in fade-in duration-300" onClick={onClose} />
      <div className="relative bg-white w-full max-w-xl rounded-t-[44px] animate-in slide-in-from-bottom duration-500 max-h-[94vh] flex flex-col shadow-[0_-20px_60px_rgba(0,0,0,0.2)]">
        <div className="flex flex-col items-center pt-4 pb-2 sticky top-0 bg-white z-20 rounded-t-[44px]">
          <div className="w-14 h-1.5 bg-gray-100 rounded-full mb-4" />
          <button onClick={onClose} className="absolute right-6 top-8 bg-gray-50 text-gray-400 p-2.5 rounded-full active:scale-90 transition-all">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><path d="M18 6 6 18M6 6l12 12"/></svg>
          </button>
        </div>
        <div className="flex-grow overflow-y-auto px-8 pb-40 no-scrollbar space-y-8">
          <div className="flex gap-5 items-center">
            <div className="w-28 h-28 bg-gray-50 rounded-3xl p-3 border border-gray-100 flex items-center justify-center shrink-0 shadow-inner">
              <img src={product.images[0]} className="w-full h-full object-contain" alt={product.name} />
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] font-black text-blue-600 uppercase tracking-[0.2em] mb-1">Destaque</span>
              <h3 className="text-xl font-black text-gray-900 leading-tight uppercase tracking-tight">{product.name}</h3>
              <p className="text-xs font-bold text-gray-400 mt-1 line-clamp-1">{product.description}</p>
            </div>
          </div>
          {product.variations.map(group => (
            <div key={group.id} className="space-y-4">
              <div className="flex justify-between items-center border-l-4 border-blue-600 pl-3">
                <div>
                  <h4 className="text-[11px] font-black text-gray-900 uppercase tracking-widest">{group.name}</h4>
                  <p className="text-[9px] text-gray-400 font-bold uppercase">Selecione uma opção</p>
                </div>
                {group.required && (
                  <span className={`text-[8px] font-black px-3 py-1 rounded-full uppercase tracking-widest ${selections[group.id] ? 'bg-green-100 text-green-600' : 'bg-amber-100 text-amber-600 animate-pulse'}`}>
                    {selections[group.id] ? 'Selecionado' : 'Obrigatório'}
                  </span>
                )}
              </div>
              <div className="grid grid-cols-2 gap-3">
                {group.options.map(opt => {
                  const active = selections[group.id] === opt;
                  return (
                    <button key={opt} onClick={() => setSelections({...selections, [group.id]: opt})} className={`py-4 px-2 rounded-2xl text-[10px] font-black uppercase tracking-widest border-2 transition-all duration-300 ${active ? 'bg-blue-600 border-blue-600 text-white shadow-xl scale-[1.03]' : 'bg-gray-50 border-transparent text-gray-400 hover:border-gray-200'}`}>
                      {opt}
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
          {product.extras.length > 0 && (
            <div className="space-y-4">
              <div className="flex items-center gap-3 border-l-4 border-gray-200 pl-3">
                <h4 className="text-[11px] font-black text-gray-900 uppercase tracking-widest">Turbine seu Pedido</h4>
              </div>
              <div className="space-y-2">
                {product.extras.map(extra => {
                  const active = selectedExtras.includes(extra.id);
                  return (
                    <button key={extra.id} onClick={() => toggleExtra(extra.id)} className={`w-full flex items-center justify-between p-5 rounded-3xl border-2 transition-all duration-300 ${active ? 'bg-blue-50/40 border-blue-200' : 'bg-white border-gray-100'}`}>
                      <div className="flex items-center gap-4">
                        <div className={`w-6 h-6 rounded-lg flex items-center justify-center border-2 transition-all ${active ? 'bg-blue-600 border-blue-600 text-white scale-110' : 'border-gray-200 bg-white'}`}>
                          {active && <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="4"><polyline points="20 6 9 17 4 12"/></svg>}
                        </div>
                        <span className={`text-[12px] font-black uppercase tracking-tight ${active ? 'text-gray-900' : 'text-gray-400'}`}>{extra.name}</span>
                      </div>
                      <span className="text-[11px] font-black text-blue-600">+ R$ {extra.price.toFixed(2)}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}
          <div className="bg-gray-50 rounded-3xl p-6 flex items-center justify-between border border-gray-100">
            <div className="flex flex-col">
              <span className="font-black text-[11px] uppercase text-gray-900 tracking-widest">Quantidade</span>
              <span className="text-[9px] font-bold text-gray-400 uppercase">Quantos deseja levar?</span>
            </div>
            <div className="flex items-center gap-6">
              <button onClick={() => setQty(q => Math.max(1, q-1))} className="w-12 h-12 flex items-center justify-center bg-white rounded-2xl shadow-md border border-gray-100 active:scale-90 transition-all text-gray-400"><IconMinus size={18}/></button>
              <span className="font-black text-2xl w-8 text-center text-gray-900 tracking-tighter">{qty}</span>
              <button onClick={() => setQty(q => q+1)} className="w-12 h-12 flex items-center justify-center bg-white rounded-2xl shadow-md border border-gray-100 active:scale-90 transition-all text-blue-600"><IconPlus size={18}/></button>
            </div>
          </div>
          <div className="space-y-3">
            <h4 className="text-[11px] font-black text-gray-400 uppercase tracking-widest px-1">Alguma Observação?</h4>
            <textarea value={obs} onChange={(e) => setObs(e.target.value)} placeholder="Ex: Mandar sem colher, brinde especial..." className="w-full bg-gray-50 border-none rounded-[28px] p-6 text-[12px] font-bold h-28 outline-none focus:ring-4 focus:ring-blue-100 transition-all resize-none" />
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 p-8 bg-white/95 backdrop-blur-xl border-t border-gray-100 z-30 shadow-[0_-15px_40px_rgba(0,0,0,0.05)]">
          <button onClick={() => isReady && onAdd(qty, selections, selectedExtras, obs)} disabled={!isReady} className={`w-full py-6 rounded-[28px] font-black uppercase text-[11px] tracking-[0.25em] text-white shadow-2xl transition-all flex items-center justify-between px-10 relative overflow-hidden group ${isReady ? themeColor + ' active:scale-[0.97]' : 'bg-gray-200 text-gray-400 cursor-not-allowed'}`}>
            {isReady && <div className="absolute inset-0 bg-white/20 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 skew-x-12" />}
            <span>{isReady ? 'Adicionar à Sacola' : `Falta: ${missingRequired[0]?.name}`}</span>
            {isReady && <div className="flex flex-col items-end"><span className="text-[8px] opacity-70 mb-0.5">Total</span><span className="bg-white/20 px-4 py-1.5 rounded-xl font-black text-sm">R$ {currentTotal.toFixed(2)}</span></div>}
          </button>
        </div>
      </div>
    </div>
  );
};

const ClientHome: React.FC = () => {
  const { config, categories, products, cart, addToCart, showToast } = useApp();
  const navigate = useNavigate();
  
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [search, setSearch] = useState('');
  const [showUpdateIndicator, setShowUpdateIndicator] = useState(false);
  const [quickAddProduct, setQuickAddProduct] = useState<Product | null>(null);
  const [showPromo, setShowPromo] = useState(false);

  useEffect(() => {
    const handleUpdate = () => {
      setShowUpdateIndicator(true);
      setTimeout(() => setShowUpdateIndicator(false), 2000);
    };
    window.addEventListener('data:productsUpdated', handleUpdate);
    
    // Controle do Pop-up Promocional
    const promoShown = sessionStorage.getItem('promo_shown');
    if (!promoShown && config.popupEnabled) {
      setTimeout(() => setShowPromo(true), 1500); // Delay elegante
    }

    return () => window.removeEventListener('data:productsUpdated', handleUpdate);
  }, [config.popupEnabled]);

  const closePromo = () => {
    setShowPromo(false);
    sessionStorage.setItem('promo_shown', 'true');
  };

  const filteredProducts = useMemo(() => {
    return products.filter(p => {
      const matchCat = activeCategory === 'all' || p.categoryId === activeCategory;
      const matchSearch = p.name.toLowerCase().includes(search.toLowerCase()) || 
                          p.description.toLowerCase().includes(search.toLowerCase());
      return matchCat && matchSearch && p.inStock;
    });
  }, [products, activeCategory, search]);

  const activeThemeColor = config.theme === 'food' ? 'bg-red-500' : 
                           config.theme === 'tech' ? 'bg-blue-600' : 
                           config.theme === 'dark' ? 'bg-indigo-500' : 'bg-green-600';

  const activeThemeGradient = config.theme === 'food' ? 'from-orange-400 to-red-500' : 
                              config.theme === 'tech' ? 'from-blue-400 to-indigo-600' : 
                              config.theme === 'dark' ? 'from-indigo-400 to-purple-600' : 'from-emerald-400 to-green-600';

  const handleQuickAdd = (qty: number, variations: Record<string, string>, extras: string[], obs: string) => {
    if (!quickAddProduct) return;
    addToCart({
      cartId: 'c_' + Math.random().toString(36).substr(2, 9),
      productId: quickAddProduct.id,
      quantity: qty,
      selectedVariations: variations,
      selectedExtras: extras,
      observation: obs
    });
    setQuickAddProduct(null);
  };

  const handleHelpClick = () => {
    const helpMsg = encodeURIComponent(config.whatsappHelpMessage || 'Olá! Vim pelo cardápio e preciso de ajuda.');
    window.open(`https://wa.me/${config.whatsapp}?text=${helpMsg}`, '_blank');
  };

  return (
    <div className="pb-32 bg-gray-50 min-h-screen">
      {showPromo && <PromoPopup config={config} onClose={closePromo} />}
      
      {showUpdateIndicator && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 z-[100] animate-in fade-in slide-in-from-top-4">
          <div className="bg-gray-900 text-white text-[10px] font-black uppercase px-6 py-2.5 rounded-full shadow-2xl">
            Catálogo Sincronizado
          </div>
        </div>
      )}

      {/* Banner & Brand */}
      <div className="px-4 pt-4 pb-2">
        <div className={`relative p-[3px] rounded-[48px] bg-gradient-to-br ${activeThemeGradient} shadow-[0_25px_50px_-12px_rgba(0,0,0,0.15)] animate-in fade-in zoom-in duration-700`}>
          <div className="relative h-64 w-full overflow-hidden bg-gray-200 rounded-[45px]">
            {config.banner ? <img src={config.banner} className="w-full h-full object-cover" alt="" /> : <div className={`w-full h-full bg-gradient-to-br ${activeThemeGradient}`} />}
            <div className="absolute inset-0 bg-black/30" />
            <div className="absolute bottom-6 left-6 right-6 flex flex-col items-start gap-4">
                {/* LOGO AUMENTADA PARA w-32 h-32 */}
                <div className="w-32 h-32 rounded-full bg-white p-2 shadow-2xl overflow-hidden flex items-center justify-center border-2 border-white/20 backdrop-blur-sm">
                  {config.logo && <img src={config.logo} className="w-full h-full object-contain" alt="" />}
                </div>
                <div className="w-full flex items-end justify-between">
                  <div>
                    <h1 className="text-white text-3xl font-black drop-shadow-lg tracking-tighter uppercase">{config.name}</h1>
                    <div className="flex items-center gap-2 mt-1">
                      <span className={`w-2.5 h-2.5 rounded-full shadow-[0_0_10px_rgba(74,222,128,0.5)] ${config.isOpen ? 'bg-green-400' : 'bg-red-400'}`} />
                      <span className="text-[10px] text-white font-black uppercase tracking-widest">{config.isOpen ? 'Aberto Agora' : 'Fechado'}</span>
                    </div>
                  </div>
                  
                  <button 
                    onClick={() => window.open(`https://wa.me/${config.whatsapp}`, '_blank')} 
                    className="bg-gradient-to-br from-green-400 to-green-600 text-white p-4 rounded-3xl shadow-[0_15px_30px_rgba(34,197,94,0.4)] border border-green-300/20 active:scale-95 transition-all flex items-center gap-3 group"
                  >
                    <IconWhatsApp size={24} className="group-hover:rotate-12 transition-transform duration-300" />
                    <span className="text-[10px] font-black uppercase tracking-widest hidden sm:inline-block pr-1">Suporte</span>
                  </button>
                </div>
            </div>
          </div>
        </div>
      </div>

      <header className="px-6 py-8 bg-white shadow-sm -mt-8 rounded-t-[40px] relative z-10 mx-2">
        <div className="relative">
          <IconSearch className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-300" size={18} />
          <input type="text" placeholder="Buscar por produtos..." className="w-full bg-gray-50 border-none rounded-2xl py-4 pl-12 pr-4 text-xs font-bold uppercase tracking-wide focus:ring-2 focus:ring-blue-500/10 transition-all outline-none" value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <div className="flex gap-3 overflow-x-auto py-6 no-scrollbar">
          <button onClick={() => setActiveCategory('all')} className={`flex-shrink-0 px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeCategory === 'all' ? activeThemeColor + ' text-white shadow-lg' : 'bg-gray-50 text-gray-400'}`}>Tudo</button>
          {categories.filter(c => c.active).map(cat => (
            <button key={cat.id} onClick={() => setActiveCategory(cat.id)} className={`flex-shrink-0 px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeCategory === cat.id ? activeThemeColor + ' text-white shadow-lg' : 'bg-gray-50 text-gray-400'}`}>
              {cat.icon} {cat.name}
            </button>
          ))}
        </div>
      </header>

      <div className="px-6 space-y-4 mt-6 max-w-xl mx-auto">
        {filteredProducts.map(product => (
          <div key={product.id} onClick={() => navigate(`/produto/${product.id}`)} className="bg-white rounded-[32px] p-4 flex gap-4 shadow-sm hover:shadow-md transition-all cursor-pointer border border-transparent hover:border-gray-100">
            <div className="w-24 h-24 flex-shrink-0 bg-white border border-gray-50 rounded-[20px] overflow-hidden p-2">
              <img src={product.images[0]} alt="" className="w-full h-full object-contain" />
            </div>
            <div className="flex flex-col justify-between flex-grow">
              <div>
                <h3 className="font-black text-gray-900 leading-tight line-clamp-1 uppercase text-xs">{product.name}</h3>
                <p className="text-gray-400 text-[10px] line-clamp-2 font-bold uppercase mt-1 tracking-tight">{product.description}</p>
              </div>
              <div className="flex items-center justify-between mt-auto">
                <div className="flex flex-col">
                  {product.oldPrice && <span className="text-[10px] text-gray-300 line-through font-bold">R$ {Number(product.oldPrice).toFixed(2)}</span>}
                  <span className="text-lg font-black text-blue-600 tracking-tighter">R$ {Number(product.price).toFixed(2)}</span>
                </div>
                <button 
                  onClick={(e) => { e.stopPropagation(); setQuickAddProduct(product); }} 
                  className={`${activeThemeColor} w-10 h-10 rounded-xl text-white flex items-center justify-center shadow-lg active:scale-90 transition-all`}
                >
                  <IconPlus size={20} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {quickAddProduct && (
        <QuickAddBottomSheet 
          product={quickAddProduct} 
          onClose={() => setQuickAddProduct(null)} 
          onAdd={handleQuickAdd}
          themeColor={activeThemeColor}
        />
      )}

      {/* FLOATING HELP BUTTON */}
      <button 
        onClick={handleHelpClick}
        className="fixed bottom-28 right-6 z-[60] bg-white text-gray-900 font-black py-3.5 px-6 rounded-full shadow-2xl border border-gray-100 flex items-center gap-3 active:scale-95 transition-all animate-in slide-in-from-right-10 duration-500 hover:bg-gray-50"
      >
        <span className="text-[10px] uppercase tracking-widest font-black">💬 Precisa de ajuda?</span>
      </button>

      <nav className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-xl border-t border-gray-100 px-8 py-5 flex items-center justify-between z-50 shadow-2xl">
        <button onClick={() => navigate('/')} className="flex flex-col items-center gap-1 text-blue-600"><IconHome size={22} /><span className="text-[9px] font-black uppercase tracking-widest">Início</span></button>
        <button onClick={() => navigate('/pedidos')} className="flex flex-col items-center gap-1 text-gray-300"><IconList size={22} /><span className="text-[9px] font-black uppercase tracking-widest">Pedidos</span></button>
        <button onClick={() => navigate('/carrinho')} className={`relative flex items-center gap-3 px-6 py-3.5 rounded-2xl ${activeThemeColor} text-white shadow-xl`}>
          <IconCart size={20} />
          {cart.length > 0 && <span className="absolute -top-1 -right-1 bg-red-500 text-white text-[9px] font-black w-5 h-5 rounded-full flex items-center justify-center border-2 border-white">{cart.length}</span>}
          <span className="text-[11px] font-black uppercase tracking-widest">Sacola</span>
        </button>
        <button onClick={() => navigate('/admin')} className="flex flex-col items-center gap-1 text-gray-300"><IconUser size={22} /><span className="text-[9px] font-black uppercase tracking-widest">Admin</span></button>
      </nav>
    </div>
  );
};

export default ClientHome;
