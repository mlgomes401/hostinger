
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../../App';
import { storage } from '../../services/storage';
import { IconHome, IconChevronRight, IconArrowLeft, IconList, IconWhatsApp } from '../../components/Icons';
import { Order, OrderStatus } from '../../types';

interface OrderModalProps {
  order: Order;
  onClose: () => void;
  products: any[];
  onSupport: (order: Order) => void;
}

const OrderDetailsModal: React.FC<OrderModalProps> = ({ order, onClose, products, onSupport }) => {
  const statusMap: Record<OrderStatus, { label: string, color: string, icon: string, bg: string }> = {
    new: { label: 'Novo Pedido', color: 'text-red-600', bg: 'bg-red-50', icon: '✨' },
    confirmed: { label: 'Confirmado', color: 'text-blue-600', bg: 'bg-blue-50', icon: '✅' },
    preparing: { label: 'Em Preparo', color: 'text-yellow-600', bg: 'bg-yellow-50', icon: '👨‍🍳' },
    shipped: { label: 'Em Rota', color: 'text-purple-600', bg: 'bg-purple-50', icon: '🛵' },
    delivered: { label: 'Entregue', color: 'text-green-600', bg: 'bg-green-50', icon: '🎁' },
    cancelled: { label: 'Cancelado', color: 'text-gray-600', bg: 'bg-gray-50', icon: '❌' },
  };

  const currentStatus = statusMap[order.status];

  return (
    <div className="fixed inset-0 z-[60] bg-black/60 backdrop-blur-md flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-300">
      <div className="bg-white w-full max-w-lg rounded-t-[40px] sm:rounded-[40px] max-h-[92vh] overflow-y-auto shadow-2xl no-scrollbar">
        <div className={`${currentStatus.bg} p-8 text-center relative`}>
          <button onClick={onClose} className="absolute top-6 right-6 bg-white/50 p-2.5 rounded-full text-gray-700 shadow-sm transition-all active:scale-90">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="M18 6 6 18M6 6l12 12"/></svg>
          </button>
          <div className="text-5xl mb-3">{currentStatus.icon}</div>
          <h2 className={`text-2xl font-black ${currentStatus.color} uppercase tracking-tight`}>{currentStatus.label}</h2>
          <p className="text-[10px] font-black text-gray-400 mt-1 uppercase tracking-widest">Pedido #{order.id}</p>
        </div>
        <div className="p-8 space-y-8">
          <div className="space-y-4">
            <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] px-2">Itens do Pedido</h3>
            <div className="space-y-3">
              {order.items.map((item, idx) => {
                const product = products.find(p => p.id === item.productId);
                if (!product) return null;
                return (
                  <div key={idx} className="flex gap-4 p-4 rounded-3xl bg-gray-50 border border-gray-100 items-center">
                    <div className="w-14 h-14 rounded-2xl overflow-hidden flex-shrink-0 bg-white p-1 border border-gray-100">
                      <img src={product.images[0]} alt="" className="w-full h-full object-contain" />
                    </div>
                    <div className="flex-grow">
                      <div className="flex justify-between items-start">
                        <p className="font-black text-gray-900 text-[11px] leading-tight uppercase">{item.quantity}x {product.name}</p>
                        <p className="text-xs font-black text-blue-600">R$ {(Number(product.price) * item.quantity).toFixed(2)}</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
          
          <div className="pt-6 border-t border-gray-100 flex justify-between items-center px-2">
            <span className="text-gray-400 font-black uppercase text-[10px] tracking-widest">Total do Pedido</span>
            <span className="text-2xl font-black text-gray-900 tracking-tighter">R$ {Number(order.total).toFixed(2)}</span>
          </div>

          <button 
            onClick={() => onSupport(order)}
            className="w-full bg-green-500 text-white font-black py-6 rounded-[28px] shadow-xl shadow-green-100 flex items-center justify-center gap-3 active:scale-95 transition-all uppercase text-[10px] tracking-widest"
          >
            <IconWhatsApp size={18} /> Suporte deste Pedido
          </button>
        </div>
      </div>
    </div>
  );
};

const OrdersHistory: React.FC = () => {
  const { config, products } = useApp();
  const navigate = useNavigate();
  const orders = storage.getOrders();
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);

  const activeThemeColor = config.theme === 'food' ? 'bg-red-500' : 
                           config.theme === 'tech' ? 'bg-blue-600' : 
                           config.theme === 'dark' ? 'bg-indigo-500' : 'bg-green-600';

  const statusLabel = (status: OrderStatus) => {
    const labels: Record<OrderStatus, string> = {
      new: 'Novo', confirmed: 'Confirmado', preparing: 'Preparo', 
      shipped: 'Em Rota', delivered: 'Entregue', cancelled: 'Cancelado'
    };
    return labels[status];
  };

  const handleSupportRequest = (order: Order) => {
    const date = new Date(order.createdAt).toLocaleDateString();
    const message = `Olá! 👋 Gostaria de mais informações sobre o meu pedido *#${order.id}*, realizado em ${date}. O valor total é R$ ${Number(order.total).toFixed(2)}. Pode me ajudar?`;
    window.open(`https://wa.me/${config.whatsapp}?text=${encodeURIComponent(message)}`, '_blank');
  };

  return (
    <div className="pb-32 min-h-screen bg-gray-50 animate-in fade-in duration-500">
      <header className="p-6 bg-white shadow-sm sticky top-0 z-40 flex items-center justify-between border-b border-gray-100">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate('/')} className="w-12 h-12 flex items-center justify-center bg-gray-50 rounded-2xl active:scale-90 transition-all border border-gray-100">
            <IconArrowLeft size={20} />
          </button>
          <div>
            <h1 className="text-sm font-black text-gray-900 uppercase tracking-widest leading-none">Meus Pedidos</h1>
            <p className="text-[9px] text-gray-400 font-bold uppercase tracking-wider mt-1">Histórico de compras</p>
          </div>
        </div>
      </header>
      
      <div className="p-6 space-y-5 max-w-xl mx-auto">
        {orders.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-32 text-center px-8 bg-white rounded-[44px] border border-gray-100 shadow-sm">
            <div className="w-24 h-24 bg-gray-50 rounded-full flex items-center justify-center mb-8">
              <IconList size={36} className="text-gray-200" />
            </div>
            <h2 className="text-lg font-black text-gray-800 mb-2 uppercase tracking-tight">Nenhum pedido encontrado</h2>
            <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mb-10">Você ainda não realizou compras conosco.</p>
            <button onClick={() => navigate('/')} className={`w-full ${activeThemeColor} text-white px-8 py-5 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-2xl active:scale-95 transition-all`}>
              Ir para o Cardápio
            </button>
          </div>
        ) : (
          orders.map(order => (
            <div key={order.id} onClick={() => setSelectedOrder(order)} className="bg-white rounded-[36px] p-6 shadow-sm border border-gray-100 flex flex-col gap-5 cursor-pointer hover:border-blue-100 hover:shadow-md active:scale-[0.98] transition-all group relative overflow-hidden">
              <div className="flex justify-between items-start">
                <div>
                  <span className="text-[9px] text-gray-300 font-black uppercase block mb-1 tracking-tighter">Pedido #{order.id}</span>
                  {/* Fixed invalid '2bit' to '2-digit' for minute and hour options */}
                  <span className="text-xs font-black text-gray-900 uppercase tracking-tight">{new Date(order.createdAt).toLocaleDateString()} às {new Date(order.createdAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                </div>
                <div className={`px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest ${order.status === 'delivered' ? 'bg-green-50 text-green-600' : 'bg-blue-50 text-blue-600'}`}>
                  {statusLabel(order.status)}
                </div>
              </div>
              
              <div className="flex items-center justify-between border-t border-gray-50 pt-5">
                <div className="flex flex-col">
                  <span className="text-[9px] font-bold text-gray-400 uppercase tracking-widest mb-0.5">Valor Pago</span>
                  <span className="text-xl font-black text-gray-900 tracking-tighter">R$ {Number(order.total).toFixed(2)}</span>
                </div>
                
                <div className="flex items-center gap-3">
                   <button 
                     onClick={(e) => { e.stopPropagation(); handleSupportRequest(order); }}
                     className="bg-green-50 text-green-600 p-3 rounded-2xl hover:bg-green-500 hover:text-white transition-all shadow-sm"
                     title="Suporte WhatsApp"
                   >
                     <IconWhatsApp size={18} />
                   </button>
                   <div className="flex items-center gap-1 text-blue-600 text-[9px] font-black uppercase tracking-widest group-hover:translate-x-1 transition-transform">Ver Detalhes <IconChevronRight size={14} /></div>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {selectedOrder && (
        <OrderDetailsModal 
          order={selectedOrder} 
          onClose={() => setSelectedOrder(null)} 
          products={products}
          onSupport={handleSupportRequest}
        />
      )}
    </div>
  );
};

export default OrdersHistory;
