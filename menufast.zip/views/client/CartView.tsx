
import React, { useState, useMemo, useEffect } from 'react';
import { useApp } from '../../App';
import { useNavigate } from 'react-router-dom';
import { 
  IconTrash, 
  IconMinus, 
  IconPlus, 
  IconWhatsApp, 
  IconCart, 
  IconArrowLeft
} from '../../components/Icons';
import { storage } from '../../services/storage';

const CartView: React.FC = () => {
  const { cart, products, updateCartQty, removeFromCart, config, clearCart, confirmAction, showToast } = useApp();
  const navigate = useNavigate();
  
  const savedInfo = storage.getCustomerInfo();
  const [customerName, setCustomerName] = useState(savedInfo.name);
  const [customerPhone, setCustomerPhone] = useState(savedInfo.phone);
  const [address, setAddress] = useState(savedInfo.address);
  
  const [isInputActive, setIsInputActive] = useState(false);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const financialSummary = useMemo(() => {
    let subtotal = 0;
    let savings = 0;
    cart.forEach(item => {
      const p = products.find(prod => prod.id === item.productId);
      if (!p) return;
      const extrasPrice = p.extras
        .filter(e => item.selectedExtras.includes(e.id))
        .reduce((a, c) => a + Number(c.price), 0);
      subtotal += (Number(p.price) + extrasPrice) * item.quantity;
      if (p.oldPrice) {
        savings += (p.oldPrice - p.price) * item.quantity;
      }
    });
    
    const deliveryFee = config.enableDeliveryFee ? config.deliveryFee : 0;
    return { subtotal, deliveryFee, total: subtotal + deliveryFee, savings };
  }, [cart, products, config]);

  const validation = useMemo(() => {
    if (!customerName.trim() || customerName.length < 3) return { valid: false, msg: 'Informe seu nome completo' };
    if (!customerPhone.trim() || customerPhone.length < 8) return { valid: false, msg: 'Informe seu WhatsApp' };
    return { valid: true, msg: '' };
  }, [customerName, customerPhone]);

  const persistCustomerInfo = () => {
    storage.setCustomerInfo({ name: customerName, phone: customerPhone, address });
  };

  const handleCheckoutWhatsApp = () => {
    if (!validation.valid) return showToast(validation.msg, 'error');
    persistCustomerInfo();
    
    const orderLines = cart.map(item => {
      const p = products.find(prod => prod.id === item.productId);
      const variations = Object.values(item.selectedVariations).join(', ');
      return `- ${item.quantity}x ${p?.name}${variations ? ` (${variations})` : ''}`;
    }).join('\n');
    
    let message = config.whatsappMessageTemplate || `Olá! Quero finalizar meu pedido na Saúde Suplementa.\n\n🛒 Itens:\n{{ITENS}}\n\n💰 Total: R$ {{TOTAL}}\n\nPrefiro pagar via Pix ou Cartão.`;

    message = message
      .replace(/{{NOME}}/g, customerName)
      .replace(/{{ITENS}}/g, orderLines)
      .replace(/{{TOTAL}}/g, financialSummary.total.toFixed(2));

    storage.addOrder({
      id: Math.random().toString(36).substr(2, 5).toUpperCase(),
      customerName,
      customerPhone,
      items: [...cart],
      total: financialSummary.total,
      deliveryType: 'delivery',
      paymentMethod: 'whatsapp',
      status: 'new',
      createdAt: Date.now()
    } as any);

    clearCart();
    window.open(`https://wa.me/${config.whatsapp}?text=${encodeURIComponent(message)}`, '_blank');
    navigate('/sucesso');
  };

  if (cart.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen p-10 text-center bg-white">
        <div className="w-24 h-24 bg-gray-50 rounded-full flex items-center justify-center mb-6">
          <IconCart size={32} className="text-gray-300" />
        </div>
        <h2 className="text-2xl font-black text-gray-900 uppercase tracking-tighter mb-2">Sacola Vazia</h2>
        <p className="text-gray-400 text-xs font-bold uppercase tracking-widest mb-10">Você não adicionou nenhum item ainda.</p>
        <button onClick={() => navigate('/')} className="w-full max-w-xs bg-blue-600 text-white font-black py-5 rounded-2xl shadow-xl uppercase text-[10px] tracking-widest">Explorar Suplementos</button>
      </div>
    );
  }

  return (
    <div className={`min-h-screen bg-white transition-all duration-300 ${isInputActive ? 'pb-10' : 'pb-96'}`}>
      <header className="bg-white/95 backdrop-blur-md sticky top-0 z-50 border-b border-gray-100 px-6 py-5 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="w-12 h-12 flex items-center justify-center bg-gray-50 rounded-2xl active:scale-90 transition-all border border-gray-100">
            <IconArrowLeft size={20} className="text-gray-900" />
          </button>
          <h1 className="text-sm font-black text-gray-900 uppercase tracking-widest">Minha Sacola</h1>
        </div>
        <button onClick={() => confirmAction({ title: 'Limpar Sacola?', message: 'Remover todos os itens?', onConfirm: clearCart })} className="text-[10px] font-black text-red-500 uppercase tracking-widest bg-red-50 px-4 py-2 rounded-xl">Limpar</button>
      </header>

      <div className="p-6 space-y-8 max-w-xl mx-auto">
        <div className="space-y-4">
          {cart.map((item) => {
            const p = products.find(prod => prod.id === item.productId);
            if (!p) return null;
            return (
              <div key={item.cartId} className="flex gap-4 items-center">
                <div className="w-16 h-16 bg-gray-50 rounded-2xl overflow-hidden p-2 shrink-0 border border-gray-100 flex items-center justify-center">
                  <img src={p.images[0]} className="w-full h-full object-contain" alt={p.name} />
                </div>
                <div className="flex-grow">
                  <h4 className="font-black text-gray-900 text-[10px] uppercase truncate">{p.name}</h4>
                  <p className="text-[9px] text-gray-400 font-bold uppercase truncate">{Object.values(item.selectedVariations).join(', ')}</p>
                  <div className="flex items-center justify-between mt-1">
                    <span className="font-black text-blue-600 text-xs">R$ {(Number(p.price) * item.quantity).toFixed(2)}</span>
                    <div className="flex items-center bg-gray-50 rounded-xl p-1 border border-gray-100">
                      <button onClick={() => updateCartQty(item.cartId, item.quantity - 1)} className="w-7 h-7 flex items-center justify-center bg-white rounded-lg shadow-sm"><IconMinus size={10}/></button>
                      <span className="w-7 text-center text-[10px] font-black">{item.quantity}</span>
                      <button onClick={() => updateCartQty(item.cartId, item.quantity + 1)} className="w-7 h-7 flex items-center justify-center bg-white rounded-lg shadow-sm"><IconPlus size={10}/></button>
                    </div>
                  </div>
                </div>
                <button onClick={() => removeFromCart(item.cartId)} className="text-gray-200 hover:text-red-400 p-2"><IconTrash size={16}/></button>
              </div>
            );
          })}
        </div>

        <button 
          onClick={() => navigate('/')}
          className="w-full py-4 rounded-2xl border-2 border-dashed border-gray-200 text-gray-400 flex items-center justify-center gap-2 hover:border-blue-200 hover:text-blue-500 transition-all active:scale-[0.98]"
        >
          <span className="text-[10px] font-black uppercase tracking-widest">Adicionar mais suplementos</span>
        </button>

        <div className="bg-gray-50 rounded-[40px] p-8 border border-gray-100 shadow-inner space-y-6">
          <h3 className="text-[10px] font-black text-gray-900 uppercase tracking-widest border-l-4 border-blue-600 pl-4">Dados do Pedido</h3>
          <div className="space-y-4">
              <input value={customerName} onFocus={() => setIsInputActive(true)} onBlur={() => setIsInputActive(false)} onChange={e => setCustomerName(e.target.value)} className="w-full bg-white border-none rounded-2xl p-5 text-[12px] font-bold outline-none shadow-sm" placeholder="Nome Completo" />
              <input value={customerPhone} onFocus={() => setIsInputActive(true)} onBlur={() => setIsInputActive(false)} onChange={e => setCustomerPhone(e.target.value)} className="w-full bg-white border-none rounded-2xl p-5 text-[12px] font-bold outline-none shadow-sm" placeholder="WhatsApp (DDD + Número)" />
              <textarea value={address} onFocus={() => setIsInputActive(true)} onBlur={() => setIsInputActive(false)} onChange={e => setAddress(e.target.value)} className="w-full bg-white border-none rounded-2xl p-5 text-[12px] font-bold h-24 resize-none outline-none shadow-sm" placeholder="Endereço de Entrega (Opcional)" />
          </div>
        </div>
      </div>

      <div className={`fixed bottom-0 inset-x-0 p-8 bg-white/95 backdrop-blur-xl border-t border-gray-100 z-50 shadow-[0_-20px_50px_rgba(0,0,0,0.08)]`}>
        <div className="max-w-xl mx-auto space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex flex-col">
              <span className="text-[10px] font-black text-blue-600 uppercase tracking-widest mb-1">Total do Pedido</span>
              <span className="text-3xl font-black text-gray-900 tracking-tighter">R$ {financialSummary.total.toFixed(2)}</span>
            </div>
            {financialSummary.savings > 0 && (
              <div className="bg-green-50 px-4 py-2 rounded-2xl text-right">
                <span className="text-[9px] font-black text-green-600 uppercase block">Você economizou</span>
                <span className="text-sm font-black text-green-600 tracking-tight">R$ {financialSummary.savings.toFixed(2)}</span>
              </div>
            )}
          </div>

          <button 
            onClick={handleCheckoutWhatsApp}
            className={`w-full py-6 rounded-[28px] flex items-center justify-center gap-4 transition-all active:scale-[0.97] shadow-2xl shadow-green-100 ${validation.valid ? 'bg-green-600 text-white' : 'bg-gray-100 text-gray-300'}`}
          >
            <IconWhatsApp size={22} />
            <span className="text-[12px] font-black uppercase tracking-[0.2em]">Finalizar no WhatsApp</span>
          </button>
          
          <p className="text-[8px] text-gray-400 font-bold uppercase text-center tracking-widest">Leve mais e economize no frete!</p>
        </div>
      </div>
    </div>
  );
};

export default CartView;
