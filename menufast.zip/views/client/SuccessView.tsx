
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../../App';
import { IconHome, IconWhatsApp, IconChevronRight } from '../../components/Icons';

const SuccessView: React.FC = () => {
  const navigate = useNavigate();
  const { config } = useApp();

  return (
    <div className="min-h-screen bg-white flex flex-col items-center justify-center p-10 text-center animate-in fade-in duration-1000">
      <div className="relative mb-16">
        {/* Background Aura */}
        <div className="absolute inset-0 bg-green-500/20 blur-[80px] rounded-full scale-150 animate-pulse" />
        
        <div className="relative w-40 h-40 bg-green-50 rounded-[56px] flex items-center justify-center shadow-inner">
          <div className="w-24 h-24 bg-green-500 rounded-[40px] flex items-center justify-center shadow-2xl shadow-green-200 animate-in zoom-in-50 duration-500 delay-200">
            <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
          </div>
        </div>
        
        {/* Sparkles */}
        <div className="absolute -top-4 -right-4 w-12 h-12 bg-yellow-400 rounded-full flex items-center justify-center text-2xl shadow-xl animate-bounce">✨</div>
        <div className="absolute -bottom-2 -left-6 w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-xl shadow-xl animate-bounce delay-300">🎉</div>
      </div>
      
      <div className="max-w-xs space-y-6">
        <h1 className="text-4xl font-black text-gray-900 tracking-tighter">Tudo Pronto!</h1>
        <p className="text-gray-400 text-sm font-black leading-relaxed px-4 uppercase tracking-tighter">
          {config.whatsappPostOrderMessage || "Recebemos seu pedido e já estamos conferindo 😊"}
        </p>
      </div>
      
      <div className="w-full max-w-sm mt-12 space-y-4 px-6">
        <button 
          onClick={() => window.open(`https://wa.me/${config.whatsapp}`, '_blank')}
          className="w-full bg-green-500 text-white font-black py-6 rounded-[30px] shadow-2xl shadow-green-200 flex items-center justify-center gap-4 active:scale-95 transition-all uppercase text-xs tracking-widest"
        >
          <IconWhatsApp size={22} /> Enviar no WhatsApp
        </button>
        
        <button 
          onClick={() => navigate('/')}
          className="w-full bg-gray-50 text-gray-900 font-black py-6 rounded-[30px] flex items-center justify-center gap-2 active:scale-95 transition-all uppercase text-xs tracking-widest border border-gray-100"
        >
          <IconHome size={18} /> Voltar ao Início
        </button>
      </div>
      
      <div className="fixed bottom-12 left-0 right-0 flex flex-col items-center gap-2">
         <span className="text-[10px] font-black text-gray-200 uppercase tracking-[0.4em]">Experiência Premium</span>
         <div className="w-12 h-1 bg-gray-100 rounded-full" />
      </div>
    </div>
  );
};

export default SuccessView;
